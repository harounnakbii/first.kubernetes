import { LayoutState } from '../types';

const STORAGE_KEY = 'app-layout-state';

export const defaultLayoutState: LayoutState = {
  sidebarCollapsed: false,
  sidebarWidth: 260,
  theme: 'light',
};

/**
 * Persiste l'état du layout dans localStorage. L'écriture déclenche
 * nativement l'événement "storage" sur les AUTRES onglets ouverts
 * (jamais sur celui qui écrit) — pas besoin de canal dédié.
 */
export function saveLayoutState(state: LayoutState): void {
  if (typeof window === 'undefined') return;

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.warn('Impossible de persister le layout dans localStorage', error);
  }
}

export function loadLayoutState(): LayoutState {
  if (typeof window === 'undefined') return defaultLayoutState;

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...defaultLayoutState, ...JSON.parse(raw) } : defaultLayoutState;
  } catch (error) {
    console.warn('Impossible de lire le layout depuis localStorage', error);
    return defaultLayoutState;
  }
}

/**
 * S'abonne aux changements de layout faits depuis un autre onglet, via
 * l'événement natif "storage". Retourne une fonction de désabonnement
 * à appeler au démontage.
 */
export function subscribeToLayoutChanges(callback: (state: LayoutState) => void): () => void {
  if (typeof window === 'undefined') return () => {};

  const handler = (event: StorageEvent) => {
    if (event.key !== STORAGE_KEY || !event.newValue) return;

    try {
      callback({ ...defaultLayoutState, ...JSON.parse(event.newValue) });
    } catch (error) {
      console.warn('Valeur de layout invalide reçue via storage event', error);
    }
  };

  window.addEventListener('storage', handler);
  return () => window.removeEventListener('storage', handler);
}
