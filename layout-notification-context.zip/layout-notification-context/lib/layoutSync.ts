import { LayoutState } from '../types';

const CHANNEL_NAME = 'app-layout-sync';
const STORAGE_KEY = 'app-layout-state';

export const defaultLayoutState: LayoutState = {
  sidebarCollapsed: false,
  sidebarWidth: 260,
  theme: 'light',
};

const channel = typeof window !== 'undefined'
  ? new BroadcastChannel(CHANNEL_NAME)
  : null;

/**
 * Persiste l'état du layout et notifie tous les autres onglets ouverts
 * (BroadcastChannel ne notifie jamais l'onglet émetteur lui-même).
 */
export function saveLayoutState(state: LayoutState): void {
  if (typeof window === 'undefined') return;

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.warn('Impossible de persister le layout dans localStorage', error);
  }

  channel?.postMessage(state);
}

export function loadLayoutState(): LayoutState {
  if (typeof window === 'undefined') return defaultLayoutState;

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...defaultLayoutState, ...JSON.parse(raw) } : defaultLayoutState;
  } catch (error) {
    console.warn('Impossible de lire le layout depuis localStorage', error);
    return defaultLayoutState;
  }
}

/**
 * S'abonne aux changements de layout faits depuis un autre onglet.
 * Retourne une fonction de désabonnement à appeler au démontage.
 */
export function subscribeToLayoutChanges(callback: (state: LayoutState) => void): () => void {
  if (!channel) return () => {};

  const handler = (event: MessageEvent<LayoutState>) => callback(event.data);
  channel.addEventListener('message', handler);
  return () => channel.removeEventListener('message', handler);
}
