/**
 * Quand l'utilisateur acquitte une notification (clic sur un produit ou
 * une famille) dans un onglet, ce canal notifie ses autres onglets
 * ouverts pour qu'ils marquent la même notification comme vue —
 * évite qu'un point de notification reste affiché dans un onglet
 * alors qu'il vient d'être acquitté dans un autre.
 */

export type AcknowledgeMessage =
  | { type: 'acknowledge-product'; familyId: string; productId: string }
  | { type: 'acknowledge-family'; familyId: string };

const CHANNEL_NAME = 'product-acknowledge-sync';

const channel = typeof window !== 'undefined'
  ? new BroadcastChannel(CHANNEL_NAME)
  : null;

export function broadcastAcknowledgeProduct(familyId: string, productId: string): void {
  channel?.postMessage({ type: 'acknowledge-product', familyId, productId } satisfies AcknowledgeMessage);
}

export function broadcastAcknowledgeFamily(familyId: string): void {
  channel?.postMessage({ type: 'acknowledge-family', familyId } satisfies AcknowledgeMessage);
}

export function subscribeToAcknowledgeMessages(
  callback: (message: AcknowledgeMessage) => void
): () => void {
  if (!channel) return () => {};

  const handler = (event: MessageEvent<AcknowledgeMessage>) => callback(event.data);
  channel.addEventListener('message', handler);
  return () => channel.removeEventListener('message', handler);
}
