/**
 * Quand l'utilisateur acquitte une notification (clic sur un produit ou
 * une famille) dans un onglet, on écrit l'événement dans localStorage.
 * Ça déclenche nativement l'événement "storage" sur les AUTRES onglets
 * ouverts (jamais sur celui qui écrit) — pas besoin de canal dédié.
 */

export type AcknowledgeMessage =
  | { type: 'acknowledge-product'; familyId: string; productId: string }
  | { type: 'acknowledge-family'; familyId: string };

const STORAGE_KEY = 'product-acknowledge-event';

function writeEvent(message: AcknowledgeMessage): void {
  if (typeof window === 'undefined') return;

  try {
    // Le timestamp garantit une valeur différente à chaque écriture,
    // même si le même produit est acquitté deux fois de suite :
    // "storage" ne se déclenche que si la valeur change réellement.
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...message, ts: Date.now() }));
  } catch (error) {
    console.warn('Impossible d\'écrire l\'événement d\'acquittement dans localStorage', error);
  }
}

export function broadcastAcknowledgeProduct(familyId: string, productId: string): void {
  writeEvent({ type: 'acknowledge-product', familyId, productId });
}

export function broadcastAcknowledgeFamily(familyId: string): void {
  writeEvent({ type: 'acknowledge-family', familyId });
}

/**
 * S'abonne aux acquittements faits depuis un autre onglet, via
 * l'événement natif "storage".
 */
export function subscribeToAcknowledgeMessages(
  callback: (message: AcknowledgeMessage) => void
): () => void {
  if (typeof window === 'undefined') return () => {};

  const handler = (event: StorageEvent) => {
    if (event.key !== STORAGE_KEY || !event.newValue) return;

    try {
      const { ts, ...message } = JSON.parse(event.newValue);
      callback(message as AcknowledgeMessage);
    } catch (error) {
      console.warn('Valeur d\'acquittement invalide reçue via storage event', error);
    }
  };

  window.addEventListener('storage', handler);
  return () => window.removeEventListener('storage', handler);
}
