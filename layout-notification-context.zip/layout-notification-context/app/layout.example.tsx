import { AppLayoutProvider } from '../contexts/AppLayoutProvider';
import { ProductProvider } from '../contexts/ProductContext';
import { MainSidebar } from '../components/MainSidebar';
import { ProductFamilyTree } from '../components/ProductFamilyTree';

// Exemple d'intégration dans app/layout.tsx (Next.js App Router).
// QueryClientProvider (React Query) est supposé déjà configuré plus haut
// dans l'arbre, ou à ajouter ici selon votre setup existant.
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <AppLayoutProvider>
          <ProductProvider>
            <div style={{ display: 'flex' }}>
              <MainSidebar>
                <ProductFamilyTree />
              </MainSidebar>
              <main style={{ flex: 1 }}>{children}</main>
            </div>
          </ProductProvider>
        </AppLayoutProvider>
      </body>
    </html>
  );
}
