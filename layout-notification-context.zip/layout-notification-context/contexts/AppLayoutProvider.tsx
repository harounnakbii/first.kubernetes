'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { LayoutState } from '../types';
import { defaultLayoutState, loadLayoutState, saveLayoutState, subscribeToLayoutChanges } from '../lib/layoutSync';

interface LayoutContextValue {
  layout: LayoutState;
  updateLayout: (partial: Partial<LayoutState>) => void;
}

const LayoutContext = createContext<LayoutContextValue | null>(null);

export function AppLayoutProvider({ children }: { children: React.ReactNode }) {
  // Lazy init : lu une seule fois au montage, évite un flash au premier rendu
  const [layout, setLayout] = useState<LayoutState>(() => loadLayoutState());

  useEffect(() => {
    // Écoute les changements faits depuis un autre onglet
    const unsubscribe = subscribeToLayoutChanges((newState) => {
      setLayout(newState);
    });
    return unsubscribe;
  }, []);

  const updateLayout = (partial: Partial<LayoutState>) => {
    setLayout(prev => {
      const next = { ...prev, ...partial };
      saveLayoutState(next); // persiste + notifie les autres onglets
      return next;
    });
  };

  return (
    <LayoutContext.Provider value={{ layout, updateLayout }}>
      {children}
    </LayoutContext.Provider>
  );
}

export function useAppLayout(): LayoutContextValue {
  const ctx = useContext(LayoutContext);
  if (!ctx) throw new Error('useAppLayout doit être utilisé à l\'intérieur de AppLayoutProvider');
  return ctx;
}

export { defaultLayoutState };
