'use client';

import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ProductFamily } from '../types';
import { detectFamilyChanges } from '../lib/detectFamilyChanges';
import { loadUnacknowledgedFromStorage, saveUnacknowledgedToStorage } from '../lib/localStorageHelpers';
import {
  broadcastAcknowledgeFamily,
  broadcastAcknowledgeProduct,
  subscribeToAcknowledgeMessages,
} from '../lib/productAcknowledgeSync';

interface ProductContextValue {
  families: ProductFamily[] | undefined;
  isLoading: boolean;
  /** familyId -> Set<productId> non encore acquittés par l'utilisateur */
  unacknowledged: Map<string, Set<string>>;
  acknowledgeProduct: (familyId: string, productId: string) => void;
  acknowledgeFamily: (familyId: string) => void;
}

const ProductContext = createContext<ProductContextValue | null>(null);

async function fetchProductFamilies(): Promise<ProductFamily[]> {
  const response = await fetch('/api/product-families');
  if (!response.ok) {
    throw new Error(`Erreur lors du chargement des familles de produits (${response.status})`);
  }
  return response.json();
}

export function ProductProvider({ children }: { children: React.ReactNode }) {
  const { data: families, isLoading } = useQuery({
    queryKey: ['product-families'],
    queryFn: fetchProductFamilies,
    refetchInterval: 30_000,
  });

  const previousFamiliesRef = useRef<ProductFamily[] | null>(null);
  const isFirstLoadRef = useRef(true);

  const [unacknowledged, setUnacknowledged] = useState<Map<string, Set<string>>>(
    () => loadUnacknowledgedFromStorage()
  );

  // Persiste à chaque changement d'état
  useEffect(() => {
    saveUnacknowledgedToStorage(unacknowledged);
  }, [unacknowledged]);

  // Détecte les changements à chaque nouveau poll
  useEffect(() => {
    if (!families) return;

    if (isFirstLoadRef.current) {
      // Premier chargement : rien à comparer. Les notifications restaurées
      // depuis localStorage (session précédente) restent affichées telles quelles.
      isFirstLoadRef.current = false;
      previousFamiliesRef.current = families;
      return;
    }

    if (previousFamiliesRef.current) {
      const detected = detectFamilyChanges(previousFamiliesRef.current, families);

      setUnacknowledged(prev => {
        let hasAnyNewChange = false;
        const next = new Map(prev);

        for (const [familyId, changeInfo] of detected) {
          if (changeInfo.changedProductIds.size === 0) continue;

          hasAnyNewChange = true;
          const merged = new Set(next.get(familyId) ?? []);
          changeInfo.changedProductIds.forEach(id => merged.add(id));
          next.set(familyId, merged);
        }

        return hasAnyNewChange ? next : prev;
      });
    }

    previousFamiliesRef.current = families;
  }, [families]);

  const acknowledgeProduct = useCallback((familyId: string, productId: string, fromBroadcast = false) => {
    setUnacknowledged(prev => {
      const set = prev.get(familyId);
      if (!set?.has(productId)) return prev;

      const next = new Map(prev);
      const updated = new Set(set);
      updated.delete(productId);

      if (updated.size === 0) next.delete(familyId);
      else next.set(familyId, updated);

      return next;
    });

    // Notifie les autres onglets, sauf si ce clic vient déjà d'un autre onglet
    if (!fromBroadcast) broadcastAcknowledgeProduct(familyId, productId);
  }, []);

  const acknowledgeFamily = useCallback((familyId: string, fromBroadcast = false) => {
    setUnacknowledged(prev => {
      if (!prev.has(familyId)) return prev;
      const next = new Map(prev);
      next.delete(familyId);
      return next;
    });

    if (!fromBroadcast) broadcastAcknowledgeFamily(familyId);
  }, []);

  // Synchronise les acquittements faits depuis d'autres onglets
  useEffect(() => {
    const unsubscribe = subscribeToAcknowledgeMessages((message) => {
      if (message.type === 'acknowledge-product') {
        acknowledgeProduct(message.familyId, message.productId, true);
      } else {
        acknowledgeFamily(message.familyId, true);
      }
    });
    return unsubscribe;
  }, [acknowledgeProduct, acknowledgeFamily]);

  return (
    <ProductContext.Provider
      value={{
        families,
        isLoading,
        unacknowledged,
        acknowledgeProduct: (familyId, productId) => acknowledgeProduct(familyId, productId),
        acknowledgeFamily: (familyId) => acknowledgeFamily(familyId),
      }}
    >
      {children}
    </ProductContext.Provider>
  );
}

export function useProductContext(): ProductContextValue {
  const ctx = useContext(ProductContext);
  if (!ctx) throw new Error('useProductContext doit être utilisé à l\'intérieur de ProductProvider');
  return ctx;
}
