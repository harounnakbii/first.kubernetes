# Layout & Product Notification Context

Deux Contexts React complémentaires pour une app Next.js :

1. **`AppLayoutProvider`** — état du layout (sidebar, thème), propre à
   chaque utilisateur, synchronisé entre ses propres onglets via
   l'événement natif `storage` + persisté en `localStorage`.
2. **`ProductProvider`** — état des familles de produits, avec polling
   30s, détection de changement (`isRestricted`, ajout, suppression), et
   notifications "non vues" persistées jusqu'à acquittement (clic),
   elles aussi synchronisées entre onglets via `storage`.

Aucun serveur/infra supplémentaire requis (pas de SignalR, pas de SSE,
pas de Redis) — tout repose sur du polling HTTP classique + `localStorage`
et son événement `storage` natif (pas de `BroadcastChannel`).

## Structure

```
types.ts                              Types partagés (Product, ProductFamily, LayoutState, etc.)

lib/
  detectFamilyChanges.ts              Comparaison entre deux snapshots de familles
  localStorageHelpers.ts              (Dé)sérialisation des notifications non acquittées
  layoutSync.ts                       Sync layout entre onglets (storage event + localStorage)
  productAcknowledgeSync.ts           Sync des acquittements de notifications entre onglets (storage event)

contexts/
  AppLayoutProvider.tsx                Context du layout (sidebar, thème)
  ProductContext.tsx                   Context des produits (polling, détection, notifications)

components/
  MainSidebar.tsx                      Sidebar consommant AppLayoutProvider + badge de notifs
  ProductNotificationBadge.tsx         Badge du nombre total de notifications non vues
  ProductFamilyTree.tsx                TreeView des familles/produits avec points de notification

app/
  layout.example.tsx                   Exemple d'intégration des deux providers dans le layout racine
```

## Installation

```bash
npm install @tanstack/react-query
```

`localStorage` et son événement `storage` sont des API natives du
navigateur, aucune dépendance npm nécessaire pour la synchronisation
entre onglets.

## Utilisation

```tsx
// app/layout.tsx
import { AppLayoutProvider } from '@/contexts/AppLayoutProvider';
import { ProductProvider } from '@/contexts/ProductContext';

export default function RootLayout({ children }) {
  return (
    <AppLayoutProvider>
      <ProductProvider>
        {children}
      </ProductProvider>
    </AppLayoutProvider>
  );
}
```

Puis, n'importe où dans l'app :

```tsx
import { useAppLayout } from '@/contexts/AppLayoutProvider';
import { useProductContext } from '@/contexts/ProductContext';

function SomeComponent() {
  const { layout, updateLayout } = useAppLayout();
  const { families, unacknowledged, acknowledgeProduct } = useProductContext();
  // ...
}
```

## Comportements clés

### Layout (sidebar, thème)
- Modifier le layout dans un onglet (`updateLayout({ sidebarCollapsed: true })`)
  met à jour immédiatement cet onglet et persiste en `localStorage`.
  Cette écriture déclenche nativement l'événement `storage` sur tous les
  autres onglets ouverts.
- L'événement `storage` ne se déclenche **jamais sur l'onglet qui a
  lui-même écrit la valeur** — seulement sur les autres — donc pas de
  double mise à jour, sans logique supplémentaire à écrire.
- Au chargement d'un nouvel onglet, l'état est lu directement depuis
  `localStorage` (pas d'attente du premier événement).

### Notifications produits
- Le polling (30s, via React Query) est centralisé dans
  `ProductProvider` — un seul point d'appel réseau, partagé par toute
  l'app, peu importe combien de composants consomment `useProductContext()`.
- Un produit est marqué "non acquitté" dès qu'il est ajouté, supprimé,
  ou que son `isRestricted` change — et le reste **jusqu'au clic** de
  l'utilisateur sur ce produit ou sur sa famille.
- L'acquittement est lui aussi synchronisé entre onglets via l'événement
  `storage` : cliquer sur un produit dans un onglet marque la
  notification comme vue dans tous les autres onglets ouverts
  (`productAcknowledgeSync.ts`). Un timestamp est ajouté à chaque
  écriture pour garantir que `storage` se déclenche même si le même
  produit est acquitté deux fois d'affilée.
- L'état des notifications non acquittées survit à un rechargement de
  page (F5) grâce à la persistance `localStorage`.

## Points d'attention

- **`'use client'` obligatoire** sur les providers et composants qui
  utilisent `localStorage`, l'événement `storage`, ou des hooks React
  (`useState`, `useEffect`) — ces API n'existent pas côté serveur (SSR).
- **Flash visuel au premier rendu SSR** : le serveur ne connaît pas
  l'état `localStorage` (propre au navigateur). Le layout par défaut
  s'affiche brièvement avant que l'état réel se charge côté client. Si
  ce détail est gênant, envisagez de stocker `sidebarCollapsed` dans un
  cookie plutôt qu'en `localStorage`, pour que le SSR en ait connaissance.
- **`GET /api/product-families`** (appelé par `ProductProvider`) est à
  adapter à votre endpoint réel — inclure vos headers d'authentification
  OAuth2 si nécessaire (`fetch` supporte nativement les headers,
  contrairement à `EventSource` utilisé dans l'approche SSE).
- **Le `ProductContext` enveloppe React Query, ne le remplace pas** :
  le cache, la déduplication et la gestion d'erreur/retry restent gérés
  par `useQuery` à l'intérieur du provider.
