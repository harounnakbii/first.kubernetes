export interface Product {
  id: string;
  name: string;
  isRestricted: boolean;
}

export interface ProductFamily {
  id: string;
  name: string;
  products: Product[];
}

export interface ChangeInfo {
  familyId: string;
  hasChange: boolean;
  changedProductIds: Set<string>;
  addedProductIds: Set<string>;
  removedProductIds: Set<string>;
  restrictionChangedProductIds: Set<string>;
}

export type SerializedUnacknowledged = Record<string, string[]>;

export interface LayoutState {
  sidebarCollapsed: boolean;
  sidebarWidth: number;
  theme: 'light' | 'dark';
}
