'use client';

import { useAppLayout } from '../contexts/AppLayoutProvider';
import { ProductNotificationBadge } from './ProductNotificationBadge';

export function MainSidebar({ children }: { children?: React.ReactNode }) {
  const { layout, updateLayout } = useAppLayout();

  return (
    <aside
      style={{
        width: layout.sidebarCollapsed ? 60 : layout.sidebarWidth,
        transition: 'width 0.2s ease',
        borderRight: '1px solid #e5e7eb',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 12 }}>
        {!layout.sidebarCollapsed && <span style={{ fontWeight: 600 }}>Menu</span>}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <ProductNotificationBadge />
          <button
            onClick={() => updateLayout({ sidebarCollapsed: !layout.sidebarCollapsed })}
            aria-label="Réduire/Étendre le menu"
          >
            {layout.sidebarCollapsed ? '→' : '←'}
          </button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        {children}
      </div>
    </aside>
  );
}
