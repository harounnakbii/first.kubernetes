'use client';

import { useState } from 'react';
import { useProductContext } from '../contexts/ProductContext';

const dotStyleFamily: React.CSSProperties = {
  display: 'inline-block',
  width: 8,
  height: 8,
  borderRadius: '50%',
  backgroundColor: '#f97316',
  marginLeft: 6,
};

const dotStyleProduct: React.CSSProperties = {
  display: 'inline-block',
  width: 6,
  height: 6,
  borderRadius: '50%',
  backgroundColor: '#f97316',
  marginLeft: 6,
};

function FamilyNode({ familyId, familyName, products, changedProductIds, onAcknowledgeFamily, onAcknowledgeProduct }: {
  familyId: string;
  familyName: string;
  products: { id: string; name: string; isRestricted: boolean }[];
  changedProductIds: Set<string> | undefined;
  onAcknowledgeFamily: (familyId: string) => void;
  onAcknowledgeProduct: (familyId: string, productId: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const hasFamilyChange = !!changedProductIds && changedProductIds.size > 0;

  const handleToggleExpand = (e: React.MouseEvent) => {
    e.stopPropagation();
    setExpanded(prev => !prev);
  };

  return (
    <li style={{ listStyle: 'none', marginBottom: 4 }}>
      <div style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
        <span onClick={handleToggleExpand} style={{ marginRight: 6, userSelect: 'none' }}>
          {expanded ? '▾' : '▸'}
        </span>
        <span onClick={() => onAcknowledgeFamily(familyId)}>
          {familyName}
          {hasFamilyChange && <span style={dotStyleFamily} title="Changement non lu" />}
        </span>
      </div>

      {expanded && (
        <ul style={{ paddingLeft: 24, marginTop: 4 }}>
          {products.map(product => (
            <li
              key={product.id}
              style={{ listStyle: 'none', cursor: 'pointer', padding: '2px 0' }}
              onClick={() => onAcknowledgeProduct(familyId, product.id)}
            >
              {product.name}
              {product.isRestricted && (
                <span style={{ marginLeft: 6, fontSize: 12, color: '#dc2626' }}>(restreint)</span>
              )}
              {changedProductIds?.has(product.id) && <span style={dotStyleProduct} title="Changement non lu" />}
            </li>
          ))}
        </ul>
      )}
    </li>
  );
}

export function ProductFamilyTree() {
  const { families, isLoading, unacknowledged, acknowledgeFamily, acknowledgeProduct } = useProductContext();

  if (isLoading) return <div style={{ padding: 12 }}>Chargement...</div>;
  if (!families) return null;

  return (
    <ul style={{ paddingLeft: 0, margin: 0 }}>
      {families.map(family => (
        <FamilyNode
          key={family.id}
          familyId={family.id}
          familyName={family.name}
          products={family.products}
          changedProductIds={unacknowledged.get(family.id)}
          onAcknowledgeFamily={acknowledgeFamily}
          onAcknowledgeProduct={acknowledgeProduct}
        />
      ))}
    </ul>
  );
}
