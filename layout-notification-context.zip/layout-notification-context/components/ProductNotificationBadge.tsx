'use client';

import { useProductContext } from '../contexts/ProductContext';

export function ProductNotificationBadge() {
  const { unacknowledged } = useProductContext();

  const total = [...unacknowledged.values()].reduce((sum, set) => sum + set.size, 0);

  if (total === 0) return null;

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        minWidth: 18,
        height: 18,
        padding: '0 5px',
        borderRadius: 9,
        backgroundColor: '#f97316',
        color: 'white',
        fontSize: 11,
        fontWeight: 600,
      }}
      title={`${total} changement(s) non consulté(s)`}
    >
      {total}
    </span>
  );
}
