import { keepPreviousData, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useRef } from 'react';

export type JobRun = {
  runId: number;
  jobId: number;
  runName?: string;
  startTime: number;
  endTime?: number | null;
  state?: { lifeCycleState?: string; resultState?: string; stateMessage?: string };
};

export type RunsPage = {
  items: JobRun[];
  total: number;
};

const PAGE_SIZE = 10;
const BASE_INTERVAL = 30_000;   // aligné sur le cache backend (actifs : 1 min, L1 : 20 s)
const MAX_INTERVAL = 120_000;   // plafond quand rien ne bouge
const OPEN_MARGIN = 5 * 60_000; // plage "ouverte" si sa fin est dans les 5 dernières min

const isActive = (r: JobRun) => !r.endTime;

const runsKey = (from: Date, to: Date, jobId: number | undefined, page: number) =>
  ['runs', from.toISOString(), to.toISOString(), jobId ?? 'all', page] as const;

async function fetchRuns(
  from: Date,
  to: Date,
  jobId: number | undefined,
  page: number,
  signal: AbortSignal,
): Promise<RunsPage> {
  const params = new URLSearchParams({
    from: from.toISOString(),
    to: to.toISOString(),
    page: String(page),
    pageSize: String(PAGE_SIZE),
  });
  if (jobId !== undefined) params.set('jobId', String(jobId));

  const res = await fetch(`/api/runs?${params}`, { signal });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

/**
 * Liste paginée des runs (tri par startTime décroissant côté serveur).
 * `from` et `to` doivent être stables (state / useMemo), sinon la clé change à chaque rendu.
 */
export function useRuns(from: Date, to: Date, page: number, jobId?: number) {
  const queryClient = useQueryClient();
  const backoff = useRef({ lastUpdatedAt: 0, lastItems: undefined as JobRun[] | undefined, unchanged: 0 });

  // Remise à zéro du backoff quand l'utilisateur change de page ou de plage
  useEffect(() => {
    backoff.current = { lastUpdatedAt: 0, lastItems: undefined, unchanged: 0 };
  }, [from, to, page, jobId]);

  const query = useQuery({
    queryKey: runsKey(from, to, jobId, page),
    queryFn: ({ signal }) => fetchRuns(from, to, jobId, page, signal),

    staleTime: BASE_INTERVAL - 5_000,
    placeholderData: keepPreviousData,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: true,

    refetchInterval: (q) => {
      const { data, dataUpdatedAt } = q.state;
      if (!data) return BASE_INTERVAL;

      const rangeIsOpen = to.getTime() > Date.now() - OPEN_MARGIN;
      const hasActive = data.items.some(isActive);

      // Page 1 d'une plage ouverte : de nouveaux runs peuvent y apparaître.
      // Autres pages : on ne rafraîchit que si elles affichent des runs en cours.
      const canChange = hasActive || (page === 1 && rangeIsOpen);
      if (!canChange) return false;

      const b = backoff.current;
      if (dataUpdatedAt !== b.lastUpdatedAt) {
        b.unchanged = data.items === b.lastItems ? b.unchanged + 1 : 0;
        b.lastItems = data.items;
        b.lastUpdatedAt = dataUpdatedAt;
      }

      return Math.min(BASE_INTERVAL * 2 ** Math.floor(b.unchanged / 2), MAX_INTERVAL);
    },
  });

  // Préchargement de la page suivante : navigation instantanée
  const total = query.data?.total ?? 0;
  useEffect(() => {
    if (page * PAGE_SIZE >= total) return;
    void queryClient.prefetchQuery({
      queryKey: runsKey(from, to, jobId, page + 1),
      queryFn: ({ signal }) => fetchRuns(from, to, jobId, page + 1, signal),
      staleTime: BASE_INTERVAL - 5_000,
    });
  }, [queryClient, from, to, jobId, page, total]);

  return {
    ...query,
    totalPages: Math.max(1, Math.ceil(total / PAGE_SIZE)),
  };
}

// Utilisation :
// const { data, totalPages, isFetching } = useRuns(from, to, page, jobId);
// const runs = data?.items ?? [];
