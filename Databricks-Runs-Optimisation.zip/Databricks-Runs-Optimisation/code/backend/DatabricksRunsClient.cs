using System.Collections.Concurrent;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

// Enregistrement : voir Program.cs
// (HttpClient typé, SocketsHttpHandler avec pooling/décompression, AddStandardResilienceHandler)

public sealed class DatabricksRunsClient(HttpClient http)
{
    private const int PageSize = 25; // max autorisé par runs/list

    /// <summary>
    /// Stream des runs sur une plage, pagination par page_token, filtrage côté serveur.
    /// </summary>
    public async IAsyncEnumerable<JobRun> GetPipelineRunsAsync(
        DateTimeOffset from,
        DateTimeOffset to,
        long? jobId = null,
        bool completedOnly = true,
        bool activeOnly = false,
        [EnumeratorCancellation] CancellationToken ct = default)
    {
        string? pageToken = null;

        do
        {
            var url = $"api/2.2/jobs/runs/list"
                    + $"?start_time_from={from.ToUnixTimeMilliseconds()}"
                    + $"&start_time_to={to.ToUnixTimeMilliseconds()}"
                    + $"&limit={PageSize}"
                    + "&expand_tasks=false"                       // payload léger
                    + (completedOnly ? "&completed_only=true" : "")
                    + (activeOnly ? "&active_only=true" : "")
                    + (jobId is { } id ? $"&job_id={id}" : "")
                    + (pageToken is null ? "" : $"&page_token={Uri.EscapeDataString(pageToken)}");

            var page = await http.GetFromJsonAsync(url, RunsJsonContext.Default.RunsListResponse, ct)
                       ?? throw new InvalidOperationException("Réponse vide de runs/list");

            if (page.Runs is not null)
                foreach (var run in page.Runs)
                    yield return run;

            pageToken = page.HasMore ? page.NextPageToken : null;
        }
        while (pageToken is not null);
    }

    /// <summary>
    /// Découpe la plage en fenêtres et les récupère en parallèle.
    /// </summary>
    public async Task<IReadOnlyList<JobRun>> GetPipelineRunsParallelAsync(
        DateTimeOffset from,
        DateTimeOffset to,
        TimeSpan window,
        int maxParallel = 6,
        long? jobId = null,
        CancellationToken ct = default)
    {
        var windows = new List<(DateTimeOffset Start, DateTimeOffset End)>();
        for (var s = from; s < to; s += window)
        {
            var e = s + window < to ? s + window : to;
            windows.Add((s, e.AddMilliseconds(-1))); // évite le chevauchement aux bornes
        }

        var results = new ConcurrentBag<JobRun>();

        await Parallel.ForEachAsync(windows,
            new ParallelOptions { MaxDegreeOfParallelism = maxParallel, CancellationToken = ct },
            async (w, token) =>
            {
                await foreach (var run in GetPipelineRunsAsync(w.Start, w.End, jobId, completedOnly: true, ct: token))
                    results.Add(run);
            });

        return results
            .DistinctBy(r => r.RunId)
            .OrderBy(r => r.StartTime)
            .ToList();
    }

    // Static : le client typé est transient, la limite doit être partagée
    // par toutes les instances pour plafonner la concurrence globale.
    private static readonly SemaphoreSlim Throttle = new(initialCount: 3, maxCount: 3);

    /// <summary>
    /// Runs des dernières 24h : 3 plages de 8h récupérées en parallèle,
    /// concurrence bornée par SemaphoreSlim.
    /// </summary>
    public async Task<IReadOnlyList<JobRun>> GetLast24hRunsAsync(
        long? jobId = null,
        CancellationToken ct = default)
    {
        var to = DateTimeOffset.UtcNow;
        var from = to.AddHours(-24);
        var slice = TimeSpan.FromHours(8);
        const int slices = 3;

        var tasks = Enumerable.Range(0, slices).Select(async i =>
        {
            var start = from + slice * i;
            var end = i == slices - 1 ? to : start + slice - TimeSpan.FromMilliseconds(1);

            await Throttle.WaitAsync(ct);
            try
            {
                var runs = new List<JobRun>();
                await foreach (var run in GetPipelineRunsAsync(start, end, jobId, completedOnly: true, ct: ct))
                    runs.Add(run);
                return runs;
            }
            finally
            {
                Throttle.Release();
            }
        });

        var results = await Task.WhenAll(tasks);

        return results
            .SelectMany(r => r)
            .DistinctBy(r => r.RunId)
            .OrderBy(r => r.StartTime)
            .ToList();
    }
}

// ---------------------------------------------------------------------------
// DTO + JSON source generation (pas de réflexion, plus rapide, AOT-friendly)
// ---------------------------------------------------------------------------

public sealed record RunsListResponse(
    List<JobRun>? Runs,
    bool HasMore,
    string? NextPageToken);

public sealed record JobRun(
    long RunId,
    long JobId,
    string? RunName,
    long StartTime,
    long? EndTime,
    long? RunDuration,
    RunState? State,
    RunStatus? Status);

public sealed record RunState(
    string? LifeCycleState,
    string? ResultState,
    string? StateMessage);

public sealed record RunStatus(
    string? State,
    TerminationDetails? TerminationDetails);

public sealed record TerminationDetails(
    string? Code,
    string? Type,
    string? Message);

[JsonSourceGenerationOptions(PropertyNamingPolicy = JsonKnownNamingPolicy.SnakeCaseLower)]
[JsonSerializable(typeof(RunsListResponse))]
internal partial class RunsJsonContext : JsonSerializerContext;
