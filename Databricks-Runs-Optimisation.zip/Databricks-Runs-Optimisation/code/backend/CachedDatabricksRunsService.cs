using Microsoft.Extensions.Caching.Hybrid;
using StackExchange.Redis;

// Enregistrement : voir Program.cs

/// <summary>
/// Cache distribué des runs Databricks, plages jusqu'à 60 jours, runs pouvant durer des jours.
///
/// Principe :
/// - Le cache contient TOUS les jobs ("all") ; le filtre jobId est appliqué en mémoire.
/// - Une plage passée est mise en cache longtemps, quelle que soit la durée des runs.
/// - Elle mémorise les runs terminés + les IDs des runs encore actifs au moment du fetch.
/// - Les runs actifs viennent d'UN seul appel active_only (cache 1 min).
/// - Dès qu'un run "pending" d'une plage n'est plus actif, cette plage seule est rechargée.
/// </summary>
public sealed class CachedDatabricksRunsService(DatabricksRunsClient client, HybridCache cache)
{
    private const string KeyPrefix = "dbx:runs:all";

    private static readonly TimeSpan Day = TimeSpan.FromDays(1);
    private static readonly TimeSpan Live = TimeSpan.FromHours(8);   // diviseur de 24h
    private static readonly TimeSpan MaxRange = TimeSpan.FromDays(60);

    // Marge pour la latence de l'API : une plage n'est "close" que 5 min après sa fin.
    private static readonly TimeSpan CloseMargin = TimeSpan.FromMinutes(5);

    // Limite les appels Databricks simultanés (par process) ; les hits cache ne sont pas bridés.
    private static readonly SemaphoreSlim MissThrottle = new(4, 4);

    // Plage close sans run actif : immuable.
    private static readonly HybridCacheEntryOptions SealedOptions = new()
    {
        Expiration = TimeSpan.FromDays(70),
        LocalCacheExpiration = TimeSpan.FromHours(1)
    };

    // Plage close avec runs actifs : invalidée par événement, TTL = filet de sécurité.
    private static readonly HybridCacheEntryOptions PendingOptions = new()
    {
        Expiration = TimeSpan.FromHours(6),
        LocalCacheExpiration = TimeSpan.FromMinutes(1)
    };

    // Plage pas encore close : de nouveaux runs peuvent y démarrer.
    private static readonly HybridCacheEntryOptions LiveOptions = new()
    {
        Expiration = TimeSpan.FromMinutes(2),
        LocalCacheExpiration = TimeSpan.FromSeconds(30)
    };

    private static readonly HybridCacheEntryOptions ActiveOptions = new()
    {
        Expiration = TimeSpan.FromMinutes(1),
        LocalCacheExpiration = TimeSpan.FromSeconds(20)
    };

    // Lecture seule : ne rien écrire si la clé est absente.
    private static readonly HybridCacheEntryOptions ReadOnlyOptions = new()
    {
        Flags = HybridCacheEntryFlags.DisableLocalCacheWrite | HybridCacheEntryFlags.DisableDistributedCacheWrite
    };

    public Task<IReadOnlyList<JobRun>> GetLast24hRunsAsync(long? jobId = null, CancellationToken ct = default)
    {
        var to = DateTimeOffset.UtcNow;
        return GetRunsAsync(to.AddHours(-24), to, jobId, ct);
    }

    public async Task<IReadOnlyList<JobRun>> GetRunsAsync(
        DateTimeOffset from,
        DateTimeOffset to,
        long? jobId = null,
        CancellationToken ct = default)
    {
        if (to <= from)
            throw new ArgumentException("La date de fin doit être postérieure à la date de début.", nameof(to));
        if (to - from > MaxRange)
            throw new ArgumentOutOfRangeException(nameof(from), "Plage limitée à 60 jours.");

        var now = DateTimeOffset.UtcNow;

        // 1 appel (souvent servi par le cache) pour l'état à jour de tous les runs actifs
        var active = await GetActiveRunsAsync(now, ct);
        var activeIds = active.Select(r => r.RunId).ToHashSet();

        var buckets = BuildBuckets(from, to, now);
        var bucketData = await Task.WhenAll(
            buckets.Select(b => GetFreshBucketAsync(b, activeIds, ct)));

        long fromMs = from.ToUnixTimeMilliseconds();
        long toMs = to.ToUnixTimeMilliseconds();

        // Terminés d'abord : si un run vient de finir, DistinctBy garde sa version terminée.
        return bucketData
            .SelectMany(d => d.Terminated)
            .Concat(active)
            .Where(r => r.StartTime >= fromMs && r.StartTime <= toMs)
            .Where(r => jobId is null || r.JobId == jobId)
            .DistinctBy(r => r.RunId)
            .OrderBy(r => r.StartTime)
            .ToList();
    }

    /// <summary>
    /// Pré-remplit les plages closes et rafraîchit celles dont un run long vient de se terminer.
    /// </summary>
    public async Task WarmAsync(int days, CancellationToken ct = default)
    {
        var now = DateTimeOffset.UtcNow;
        var active = await GetActiveRunsAsync(now, ct);
        var activeIds = active.Select(r => r.RunId).ToHashSet();

        foreach (var b in BuildBuckets(now.AddDays(-days), now, now).Where(b => b.Closed))
            await GetFreshBucketAsync(b, activeIds, ct);
    }

    // -------------------------------------------------------------------------

    private async Task<BucketData> GetFreshBucketAsync(CacheBucket bucket, HashSet<long> activeIds, CancellationToken ct)
    {
        var data = await GetBucketAsync(bucket, ct);

        // Un run marqué actif dans cette plage ne l'est plus -> il s'est terminé : on recharge.
        if (data.PendingRunIds.Any(id => !activeIds.Contains(id)))
        {
            await cache.RemoveAsync(Key(bucket), ct);
            data = await GetBucketAsync(bucket, ct);
        }

        return data;
    }

    private async ValueTask<BucketData> GetBucketAsync(CacheBucket bucket, CancellationToken ct)
    {
        var key = Key(bucket);

        // HybridCache ne permet pas de choisir le TTL après le fetch :
        // lecture seule d'abord, puis écriture avec les options adaptées au contenu.
        var cached = await cache.GetOrCreateAsync<BucketData?>(
            key,
            _ => ValueTask.FromResult<BucketData?>(null),
            ReadOnlyOptions,
            cancellationToken: ct);

        if (cached is not null)
            return cached;

        var fresh = await FetchBucketAsync(bucket, ct);

        var options = !bucket.Closed ? LiveOptions
                    : fresh.PendingRunIds.Count > 0 ? PendingOptions
                    : SealedOptions;

        await cache.SetAsync(key, fresh, options, cancellationToken: ct);
        return fresh;
    }

    private async Task<BucketData> FetchBucketAsync(CacheBucket bucket, CancellationToken ct)
    {
        await MissThrottle.WaitAsync(ct);
        try
        {
            var terminated = new List<JobRun>();
            var pending = new List<long>();
            var end = bucket.Start + bucket.Size - TimeSpan.FromMilliseconds(1);

            await foreach (var run in client.GetPipelineRunsAsync(
                               bucket.Start, end, jobId: null, completedOnly: false, ct: ct))
            {
                if (run.EndTime is > 0) terminated.Add(run);
                else pending.Add(run.RunId);
            }

            return new BucketData(terminated, pending);
        }
        finally
        {
            MissThrottle.Release();
        }
    }

    private ValueTask<List<JobRun>> GetActiveRunsAsync(DateTimeOffset now, CancellationToken ct) =>
        cache.GetOrCreateAsync(
            $"{KeyPrefix}:active",
            async token =>
            {
                var runs = new List<JobRun>();
                await foreach (var run in client.GetPipelineRunsAsync(
                                   now - MaxRange, now, jobId: null,
                                   completedOnly: false, activeOnly: true, ct: token))
                    runs.Add(run);
                return runs;
            },
            ActiveOptions,
            cancellationToken: ct);

    private static List<CacheBucket> BuildBuckets(DateTimeOffset from, DateTimeOffset to, DateTimeOffset now)
    {
        var buckets = new List<CacheBucket>();
        var closedBefore = now - CloseMargin;
        var b = Floor(from, Day);

        // Jours entiers tant qu'ils sont clos
        while (b < to && b + Day <= closedBefore)
        {
            buckets.Add(new(b, Day, Closed: true));
            b += Day;
        }

        // Plages de 8h pour la partie récente
        var liveStart = Floor(from, Live);
        if (liveStart > b) b = liveStart;
        while (b < to)
        {
            buckets.Add(new(b, Live, Closed: b + Live <= closedBefore));
            b += Live;
        }

        return buckets;
    }

    private static string Key(CacheBucket b) =>
        $"{KeyPrefix}:{(int)b.Size.TotalHours}h:{b.Start.ToUnixTimeSeconds()}";

    private static DateTimeOffset Floor(DateTimeOffset t, TimeSpan size) =>
        new(t.UtcTicks - t.UtcTicks % size.Ticks, TimeSpan.Zero);

    private readonly record struct CacheBucket(DateTimeOffset Start, TimeSpan Size, bool Closed);
}

/// <summary>Runs terminés de la plage + IDs des runs encore actifs au moment du fetch.</summary>
public sealed record BucketData(List<JobRun> Terminated, List<long> PendingRunIds);

/// <summary>
/// Pré-chauffe le cache toutes les 6h. Un verrou Redis garantit qu'une seule
/// instance de l'API travaille à la fois, même avec plusieurs pods.
/// </summary>
public sealed class DatabricksRunsCacheWarmer(
    IServiceScopeFactory scopes,
    IConnectionMultiplexer redis,
    ILogger<DatabricksRunsCacheWarmer> logger) : BackgroundService
{
    private const string LockKey = "dbx:runs:warmer-lock";
    private static readonly TimeSpan LockTtl = TimeSpan.FromMinutes(30);

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        var lockToken = $"{Environment.MachineName}:{Guid.NewGuid():N}";
        var db = redis.GetDatabase();

        using var timer = new PeriodicTimer(TimeSpan.FromHours(6));
        do
        {
            // SET NX avec expiration : si une autre instance tient le verrou, on passe notre tour.
            if (!await db.LockTakeAsync(LockKey, lockToken, LockTtl))
            {
                logger.LogDebug("Préchauffage déjà en cours sur une autre instance");
                continue;
            }

            try
            {
                await using var scope = scopes.CreateAsyncScope();
                var svc = scope.ServiceProvider.GetRequiredService<CachedDatabricksRunsService>();
                await svc.WarmAsync(days: 60, ct);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                logger.LogWarning(ex, "Échec du préchauffage du cache Databricks");
            }
            finally
            {
                await db.LockReleaseAsync(LockKey, lockToken);
            }
        }
        while (await timer.WaitForNextTickAsync(ct));
    }
}
