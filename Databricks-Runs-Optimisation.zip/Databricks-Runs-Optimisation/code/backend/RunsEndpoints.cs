using Microsoft.Extensions.Caching.Memory;

/// <summary>
/// GET /api/runs?from=...&to=...&jobId=...&page=1&pageSize=10
/// Réponse : { items: JobRun[], total: number }, triée par startTime décroissant.
/// </summary>
public static class RunsEndpoints
{
    private static readonly TimeSpan MergedListTtl = TimeSpan.FromSeconds(20);

    public static IEndpointRouteBuilder MapRunsEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/runs", async (
            DateTimeOffset from,
            DateTimeOffset to,
            long? jobId,
            int? page,
            int? pageSize,
            CachedDatabricksRunsService runs,
            IMemoryCache memory,
            CancellationToken ct) =>
        {
            if (to <= from)
                return Results.BadRequest("La date de fin doit être postérieure à la date de début.");
            if (to - from > TimeSpan.FromDays(60))
                return Results.BadRequest("Plage limitée à 60 jours.");

            var p = Math.Max(1, page ?? 1);
            var size = Math.Clamp(pageSize ?? 10, 1, 100);

            // La liste fusionnée et triée est gardée 20 s en mémoire :
            // changer de page ne refait ni la fusion ni le tri.
            var key = $"runs-merged:{from.ToUnixTimeMilliseconds()}:{to.ToUnixTimeMilliseconds()}:{jobId}";
            var all = await memory.GetOrCreateAsync(key, async entry =>
            {
                entry.AbsoluteExpirationRelativeToNow = MergedListTtl;
                var list = await runs.GetRunsAsync(from, to, jobId, ct);
                return list
                    .OrderByDescending(r => r.StartTime)
                    .ThenByDescending(r => r.RunId)
                    .ToList();
            }) ?? [];

            var items = all.Skip((p - 1) * size).Take(size).ToList();
            return Results.Ok(new RunsPageResponse(items, all.Count));
        });

        return app;
    }
}

public sealed record RunsPageResponse(List<JobRun> Items, int Total);
