using System.Net;
using StackExchange.Redis;

// NuGet :
//   Microsoft.Extensions.Http.Resilience
//   Microsoft.Extensions.Caching.Hybrid
//   Microsoft.Extensions.Caching.StackExchangeRedis

var builder = WebApplication.CreateBuilder(args);

// --- Redis : une seule connexion partagée (cache distribué + verrou du warmer) ---
var redis = await ConnectionMultiplexer.ConnectAsync(builder.Configuration.GetConnectionString("Redis")!);
builder.Services.AddSingleton<IConnectionMultiplexer>(redis);

builder.Services.AddStackExchangeRedisCache(o =>
{
    o.ConnectionMultiplexerFactory = () => Task.FromResult<IConnectionMultiplexer>(redis);
    o.InstanceName = "myapp:";
});

// --- Cache : L1 mémoire + L2 Redis ---
builder.Services.AddMemoryCache();
builder.Services.AddHybridCache(o => o.MaximumPayloadBytes = 16 * 1024 * 1024);

// --- Client Databricks : pooling, décompression, retry/429 ---
builder.Services.AddHttpClient<DatabricksRunsClient>(c =>
{
    c.BaseAddress = new Uri(builder.Configuration["Databricks:Host"]!); // https://adb-xxx.azuredatabricks.net/
    c.DefaultRequestHeaders.Authorization = new("Bearer", builder.Configuration["Databricks:Token"]);
})
.ConfigurePrimaryHttpMessageHandler(() => new SocketsHttpHandler
{
    AutomaticDecompression = DecompressionMethods.All,
    PooledConnectionLifetime = TimeSpan.FromMinutes(5),
    MaxConnectionsPerServer = 10
})
.AddStandardResilienceHandler();

// --- Services métier ---
builder.Services.AddScoped<CachedDatabricksRunsService>();
builder.Services.AddHostedService<DatabricksRunsCacheWarmer>();

var app = builder.Build();

app.MapRunsEndpoints();

app.Run();
