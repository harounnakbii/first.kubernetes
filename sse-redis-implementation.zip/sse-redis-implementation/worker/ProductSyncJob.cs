namespace SseNotifications.Worker;

/// <summary>
/// Exemple d'intégration dans le job de synchronisation existant.
/// Remplacez SyncProductsAsync par votre logique réelle (Databricks -> SQL Server).
/// </summary>
public class ProductSyncJob
{
    private readonly NotificationClient _notificationClient;

    public ProductSyncJob(NotificationClient notificationClient)
    {
        _notificationClient = notificationClient;
    }

    public async Task RunAsync()
    {
        var changedProductIds = await SyncProductsAsync();

        // Un seul appel groupé, même si 1 ou 100 produits ont changé
        await _notificationClient.NotifyAsync("products.restrictionsChanged", changedProductIds);
    }

    private Task<List<string>> SyncProductsAsync()
    {
        // ... récupération Databricks + comparaison + update SQL Server ...
        // retourne la liste des IDs de produits effectivement modifiés
        throw new NotImplementedException("Logique de synchronisation existante à brancher ici");
    }
}
