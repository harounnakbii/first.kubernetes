using System.Net.Http.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace SseNotifications.Worker;

/// <summary>
/// Configuration du client HTTP interne. À appeler une fois dans le
/// Program.cs du worker.
/// </summary>
public static class InternalApiSetup
{
    public static IServiceCollection AddInternalApiClient(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHttpClient("InternalApi", client =>
        {
            client.BaseAddress = new Uri(configuration["Api:BaseUrl"]!);
            client.DefaultRequestHeaders.Add(
                "Authorization", $"Bearer {configuration["Api:InternalToken"]}");
        })
        .AddStandardResilienceHandler();

        return services;
    }
}

public record NotifyPayload(string EventType, List<string> ProductIds);

public class NotificationClient
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<NotificationClient> _logger;

    public NotificationClient(IHttpClientFactory httpClientFactory, ILogger<NotificationClient> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    /// <summary>
    /// Notifie l'API en un seul appel groupé plutôt qu'un appel par
    /// produit modifié : réduit le risque de perte partielle en cas de
    /// redéploiement pendant la séquence, et réduit la charge sur le
    /// relais SSE (une seule itération sur les clients au lieu de N).
    /// </summary>
    public async Task NotifyAsync(string eventType, List<string> changedProductIds)
    {
        if (changedProductIds.Count == 0) return;

        var client = _httpClientFactory.CreateClient("InternalApi");
        var payload = new NotifyPayload(eventType, changedProductIds);

        try
        {
            var response = await client.PostAsJsonAsync("/internal/notify", payload);
            response.EnsureSuccessStatusCode();

            _logger.LogInformation(
                "Notification envoyée : {EventType} ({Count} produits)",
                eventType, changedProductIds.Count);
        }
        catch (Exception ex)
        {
            // Ne jamais faire échouer le job de sync pour un échec de
            // notification : les données SQL Server sont déjà à jour,
            // le prochain cycle re-notifiera de toute façon.
            _logger.LogWarning(ex, "Échec de la notification à l'API, la sync a néanmoins réussi");
        }
    }
}
