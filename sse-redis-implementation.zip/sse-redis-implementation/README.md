# SSE + Redis — Implémentation

Notification temps réel serveur → client, avec Redis Pub/Sub comme relais
entre les pods de l'API et authentification par ticket à courte durée de
vie (compatible OAuth2, puisque `EventSource` ne peut pas envoyer de
header `Authorization`).

Voir **guide-sse-redis.pdf** pour l'explication détaillée, étape par
étape, avec le contexte de chaque décision.

## Structure

```
api/
  Models.cs                  Contrats (NotifyRequest, NotificationEvent)
  SseNotificationService.cs  Relais Redis Pub/Sub → clients SSE (channel borné)
  TicketService.cs           Auth SSE par ticket à usage unique (stocké dans Redis)
  Program.cs                 Endpoints : /api/events/ticket, /api/events, /internal/notify
  SseNotifications.Api.csproj

worker/
  NotificationClient.cs       Appel HTTP groupé vers /internal/notify
  ProductSyncJob.cs            Exemple d'intégration dans le job de sync existant

frontend/
  sseClient.ts                    Échange access_token -> ticket SSE
  useProductNotifications.ts      Hook de connexion SSE filtrée par produits suivis
  ProductFamilyPage.example.tsx   Exemple d'utilisation dans un composant
```

## Points clés de cette implémentation

- **Channel borné (`BoundedChannelOptions`, 200 messages, `DropOldest`)**
  côté API : évite qu'un client lent ou une rafale d'événements fasse
  grossir la mémoire indéfiniment.
- **Ticket à usage unique stocké dans Redis** (pas en mémoire locale) :
  fonctionne peu importe le pod qui traite la requête `/api/events`,
  contrairement à un stockage `ConcurrentDictionary` en mémoire qui ne
  serait visible que par le pod qui a créé le ticket.
- **Endpoint `/internal/notify` générique** : ne connaît jamais son
  appelant (worker actuel ou futur remplaçant), protégé par une policy
  d'autorisation dédiée (`scope: internal-notify`), pas par une logique
  couplée à "le worker".
- **Notification groupée côté worker** : un seul appel HTTP avec la
  liste complète des IDs modifiés, plutôt qu'un appel par produit —
  réduit le risque de perte partielle et la charge sur le relais SSE.

## Limitations connues (voir le PDF pour le détail)

- Redis Pub/Sub ne persiste pas les messages : un événement publié
  pendant qu'aucun pod n'est abonné (redémarrage, déploiement) est perdu
  silencieusement. Un filet de sécurité (polling de secours) est
  recommandé en complément — endpoint `/api/notifications` prévu à cet
  effet dans `Program.cs`, à brancher sur un store persistant si ce
  besoin devient critique.
- Le ticket a une durée de vie de 30 secondes : le front doit l'utiliser
  immédiatement après l'avoir obtenu, pas le mettre en cache.
- Un `access_token` OAuth2 qui expire en cours de connexion SSE ne coupe
  pas automatiquement le flux (le token n'est validé qu'à l'ouverture).
  Si c'est un problème pour votre modèle de sécurité, ajoutez une
  vérification périodique côté serveur qui ferme la connexion à
  expiration du token.

## Configuration attendue (`appsettings.json` / variables d'environnement)

```json
{
  "OAuth": {
    "Authority": "https://votre-idp/",
    "Audience": "votre-api"
  },
  "Redis": {
    "ConnectionString": "redis:6379"
  }
}
```

```json
{
  "Api": {
    "BaseUrl": "https://votre-api-interne/",
    "InternalToken": "<token avec scope internal-notify>"
  }
}
```
