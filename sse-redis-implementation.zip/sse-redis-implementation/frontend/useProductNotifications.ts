import { useEffect, useRef } from 'react';
import { fetchSseTicket, NotificationEvent } from './sseClient';

interface UseProductNotificationsOptions {
  watchedProductIds: string[];
  accessToken: string | null;
  onEvent: (event: NotificationEvent) => void;
}

/**
 * Ouvre une connexion SSE authentifiée (via ticket à courte durée de vie,
 * voir sseClient.ts) et filtrée sur une liste de produits suivis.
 *
 * Se reconnecte automatiquement si watchedProductIds change (nouvelle
 * vue affichée) ou si accessToken change (refresh du token OAuth2).
 */
export function useProductNotifications({
  watchedProductIds,
  accessToken,
  onEvent,
}: UseProductNotificationsOptions) {
  const eventSourceRef = useRef<EventSource | null>(null);
  const watchedKey = watchedProductIds.join(',');

  useEffect(() => {
    if (!accessToken || watchedProductIds.length === 0) return;

    let cancelled = false;
    let eventSource: EventSource | null = null;

    async function connect() {
      try {
        const ticket = await fetchSseTicket(accessToken!);
        if (cancelled) return;

        const params = new URLSearchParams({
          ticket,
          productIds: watchedKey,
        });

        eventSource = new EventSource(`/api/events?${params}`);
        eventSourceRef.current = eventSource;

        eventSource.onmessage = (event) => {
          const notification: NotificationEvent = JSON.parse(event.data);
          onEvent(notification);
        };

        eventSource.onerror = () => {
          // EventSource retente nativement la connexion. Le ticket étant
          // à usage unique, une reconnexion réseau native (même socket)
          // fonctionne, mais si le navigateur crée une toute nouvelle
          // requête après une longue coupure, il faudra un nouveau
          // ticket : voir la note dans le README sur ce cas limite.
          console.warn('Connexion SSE interrompue, reconnexion en cours...');
        };
      } catch (error) {
        console.error('Impossible d\'établir la connexion SSE', error);
      }
    }

    connect();

    return () => {
      cancelled = true;
      eventSource?.close();
      eventSourceRef.current = null;
    };
  }, [watchedKey, accessToken]);
}
