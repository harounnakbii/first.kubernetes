import { useQueryClient } from '@tanstack/react-query';
import { useProductNotifications } from './useProductNotifications';
import { useAuth } from './useAuth'; // votre hook OAuth2 existant

interface ProductFamilyPageProps {
  watchedProductIds: string[];
}

export function ProductFamilyPage({ watchedProductIds }: ProductFamilyPageProps) {
  const queryClient = useQueryClient();
  const { accessToken } = useAuth();

  useProductNotifications({
    watchedProductIds,
    accessToken,
    onEvent: (notification) => {
      if (notification.type === 'products.restrictionsChanged') {
        queryClient.invalidateQueries({ queryKey: ['product-families'] });
      }
    },
  });

  // ... reste du composant (TreeView, etc.)
  return null;
}
