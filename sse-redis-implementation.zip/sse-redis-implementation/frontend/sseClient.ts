export interface NotificationEvent {
  type: string;
  productIds: string[];
  timestamp: string;
}

/**
 * Échange l'access_token OAuth2 (header Authorization normal) contre un
 * ticket à usage unique et courte durée de vie, utilisable dans l'URL de
 * connexion SSE. EventSource ne pouvant pas envoyer de header
 * Authorization, on ne peut pas passer l'access_token directement.
 */
export async function fetchSseTicket(accessToken: string): Promise<string> {
  const response = await fetch('/api/events/ticket', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Impossible d'obtenir un ticket SSE (${response.status})`);
  }

  const data = await response.json();
  return data.ticket as string;
}
