using System.Security.Claims;
using System.Text.Json;
using SseNotifications.Api;
using StackExchange.Redis;

var builder = WebApplication.CreateBuilder(args);

// --- Authentification OAuth2 existante (JWT Bearer) ---
builder.Services.AddAuthentication("Bearer")
    .AddJwtBearer("Bearer", options =>
    {
        options.Authority = builder.Configuration["OAuth:Authority"];
        options.Audience = builder.Configuration["OAuth:Audience"];
    });

builder.Services.AddAuthorization(options =>
{
    // Policy dédiée à l'endpoint interne, jamais exposée à un utilisateur final
    options.AddPolicy("InternalOnly", policy =>
        policy.RequireClaim("scope", "internal-notify"));
});

// --- Redis (partagé entre relais SSE, tickets, et publication) ---
builder.Services.AddSingleton<IConnectionMultiplexer>(
    ConnectionMultiplexer.Connect(builder.Configuration["Redis:ConnectionString"]!));

builder.Services.AddSingleton<ITicketService, RedisTicketService>();
builder.Services.AddSingleton<SseNotificationService>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<SseNotificationService>());

var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

// -----------------------------------------------------------------------
// 1. Le front échange son access_token OAuth2 (header Authorization normal)
//    contre un ticket à courte durée de vie utilisable dans l'URL SSE.
// -----------------------------------------------------------------------
app.MapPost("/api/events/ticket", async (HttpContext context, ITicketService tickets) =>
{
    var userId = context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
    if (userId is null) return Results.Unauthorized();

    var ticket = await tickets.CreateAsync(userId, TimeSpan.FromSeconds(30));
    return Results.Ok(new { ticket });
})
.RequireAuthorization();

// -----------------------------------------------------------------------
// 2. Connexion SSE : authentifiée par le ticket (pas par un header, que
//    EventSource ne peut pas envoyer), puis filtrée par produits suivis.
// -----------------------------------------------------------------------
app.MapGet("/api/events", async (HttpContext context, ITicketService tickets, SseNotificationService sseService) =>
{
    var ticket = context.Request.Query["ticket"].ToString();
    var userId = await tickets.ConsumeAsync(ticket);

    if (userId is null)
    {
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        return;
    }

    var watchedProductIds = context.Request.Query["productIds"]
        .ToString()
        .Split(',', StringSplitOptions.RemoveEmptyEntries);

    context.Response.Headers.Append("Content-Type", "text/event-stream");
    context.Response.Headers.Append("Cache-Control", "no-cache");
    context.Response.Headers.Append("X-Accel-Buffering", "no");

    var clientId = sseService.RegisterClient(watchedProductIds, out var channel);

    try
    {
        await context.Response.WriteAsync(": connected\n\n");
        await context.Response.Body.FlushAsync();

        await foreach (var message in channel.Reader.ReadAllAsync(context.RequestAborted))
        {
            await context.Response.WriteAsync($"data: {message}\n\n");
            await context.Response.Body.FlushAsync();
        }
    }
    catch (OperationCanceledException)
    {
        // Déconnexion normale (fermeture d'onglet, navigation, etc.)
    }
    finally
    {
        sseService.UnregisterClient(clientId);
    }
});

// -----------------------------------------------------------------------
// 3. Endpoint interne générique : appelé par n'importe quelle source de
//    changement (worker aujourd'hui, autre chose demain). Contrat stable,
//    ne connaît jamais son appelant.
// -----------------------------------------------------------------------
app.MapPost("/internal/notify", async (NotifyRequest request, IConnectionMultiplexer redis) =>
{
    if (request.ProductIds.Count == 0) return Results.Ok();

    var payload = JsonSerializer.Serialize(new
    {
        type = request.EventType,
        productIds = request.ProductIds,
        timestamp = DateTime.UtcNow
    });

    await redis.GetSubscriber().PublishAsync(RedisChannel.Literal("notifications"), payload);
    return Results.Ok();
})
.RequireAuthorization("InternalOnly");

// -----------------------------------------------------------------------
// 4. Endpoint de secours (réconciliation) — voir README pour le détail
//    du filet de sécurité recommandé en complément du temps réel.
// -----------------------------------------------------------------------
app.MapGet("/api/notifications", (DateTime since) =>
{
    // À brancher sur votre store de notifications persistées si vous
    // adoptez le filet de sécurité décrit dans le guide PDF.
    return Results.Ok(Array.Empty<object>());
})
.RequireAuthorization();

app.Run();
