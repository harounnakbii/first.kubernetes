using System.Collections.Concurrent;
using System.Text.Json;
using System.Threading.Channels;
using StackExchange.Redis;

namespace SseNotifications.Api;

/// <summary>
/// S'abonne au channel Redis "notifications" au démarrage de l'API et
/// relaie chaque message reçu aux clients SSE connectés à CE pod,
/// filtrés par la liste de produits suivis par chaque client.
///
/// Le channel de chaque client est borné (DropOldest) pour éviter une
/// fuite mémoire si un client lent ne consomme pas assez vite ou en cas
/// de rafale d'événements.
/// </summary>
public class SseNotificationService : IHostedService
{
    private const int MaxQueuedMessagesPerClient = 200;

    private readonly IConnectionMultiplexer _redis;
    private readonly ILogger<SseNotificationService> _logger;
    private ISubscriber? _subscriber;

    private sealed record ClientSubscription(
        Channel<string> Channel,
        HashSet<string> WatchedProductIds);

    private readonly ConcurrentDictionary<Guid, ClientSubscription> _clients = new();

    public SseNotificationService(IConnectionMultiplexer redis, ILogger<SseNotificationService> logger)
    {
        _redis = redis;
        _logger = logger;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _subscriber = _redis.GetSubscriber();

        _subscriber.Subscribe(RedisChannel.Literal("notifications"), (_, message) =>
        {
            if (message.IsNullOrEmpty) return;

            NotificationEvent? evt;
            try
            {
                evt = JsonSerializer.Deserialize<NotificationEvent>(message!);
            }
            catch (JsonException ex)
            {
                _logger.LogWarning(ex, "Message Redis invalide reçu sur le channel notifications");
                return;
            }

            if (evt is null) return;

            foreach (var client in _clients.Values)
            {
                // Liste de produits suivis vide = le client reçoit tout
                bool isConcerned = client.WatchedProductIds.Count == 0
                    || evt.ProductIds.Any(id => client.WatchedProductIds.Contains(id));

                if (isConcerned)
                {
                    client.Channel.Writer.TryWrite(message!);
                }
            }
        });

        _logger.LogInformation("Abonné au channel Redis 'notifications'");
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        _subscriber?.UnsubscribeAll();
        return Task.CompletedTask;
    }

    /// <summary>
    /// Enregistre un nouveau client SSE. Le channel retourné est borné :
    /// si le client ne consomme pas assez vite, les messages les plus
    /// anciens sont supprimés plutôt que de laisser la mémoire grossir
    /// indéfiniment.
    /// </summary>
    public Guid RegisterClient(IEnumerable<string> watchedProductIds, out Channel<string> channel)
    {
        var id = Guid.NewGuid();

        channel = Channel.CreateBounded<string>(new BoundedChannelOptions(MaxQueuedMessagesPerClient)
        {
            FullMode = BoundedChannelFullMode.DropOldest,
            SingleReader = true,
            SingleWriter = false,
        });

        _clients[id] = new ClientSubscription(channel, new HashSet<string>(watchedProductIds));
        return id;
    }

    public void UnregisterClient(Guid id) => _clients.TryRemove(id, out _);

    public int ConnectedClientsCount => _clients.Count;
}
