namespace SseNotifications.Api;

/// <summary>
/// Contrat générique envoyé par n'importe quelle source de changement
/// (worker, autre job, admin manuel...). L'API ne connaît jamais son appelant.
/// </summary>
public record NotifyRequest(string EventType, List<string> ProductIds);

/// <summary>
/// Événement tel que sérialisé et diffusé sur Redis Pub/Sub, puis relayé
/// aux clients SSE.
/// </summary>
public record NotificationEvent(string Type, List<string> ProductIds, DateTime Timestamp);
