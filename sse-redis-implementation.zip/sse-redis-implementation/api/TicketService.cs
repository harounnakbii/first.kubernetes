using System.Text.Json;
using StackExchange.Redis;

namespace SseNotifications.Api;

/// <summary>
/// EventSource ne permet pas d'envoyer un header Authorization. Ce service
/// génère un ticket à usage unique et à durée de vie très courte, échangé
/// contre l'access_token OAuth2 (déjà validé classiquement via un endpoint
/// authentifié), pour ouvrir la connexion SSE via un paramètre de query
/// string sans jamais exposer le vrai access_token.
///
/// Stocké dans Redis (déjà présent dans le cluster) plutôt qu'en mémoire
/// locale, pour fonctionner correctement peu importe le pod qui traite
/// la requête de connexion SSE.
/// </summary>
public interface ITicketService
{
    Task<string> CreateAsync(string userId, TimeSpan ttl);
    Task<string?> ConsumeAsync(string ticket);
}

public class RedisTicketService : ITicketService
{
    private readonly IConnectionMultiplexer _redis;
    private const string KeyPrefix = "sse-ticket:";

    public RedisTicketService(IConnectionMultiplexer redis)
    {
        _redis = redis;
    }

    public async Task<string> CreateAsync(string userId, TimeSpan ttl)
    {
        var ticket = Guid.NewGuid().ToString("N");
        var db = _redis.GetDatabase();

        await db.StringSetAsync(KeyPrefix + ticket, userId, ttl);
        return ticket;
    }

    public async Task<string?> ConsumeAsync(string ticket)
    {
        var db = _redis.GetDatabase();
        var key = KeyPrefix + ticket;

        var userId = await db.StringGetAsync(key);
        if (userId.IsNullOrEmpty) return null;

        // Usage unique : le ticket est supprimé dès sa consommation,
        // même s'il a fuité (log, historique navigateur), il est déjà mort.
        await db.KeyDeleteAsync(key);

        return userId.ToString();
    }
}
