# config.ps1 — Variables globales partagées par tous les scripts ShipClass Local
# Placer dans : ~/shipclass-local/config.ps1
# Importer dans chaque script avec : . "$PSScriptRoot/config.ps1"

$Global:SC = @{
    ClusterName    = "shipclass-local"
    Namespace      = "shipclass"
    Context        = "kind-shipclass-local"
    Registry       = "localhost:5001"
    RegistryName   = "kind-registry"
    JFrogPort      = 8082
    JFrogUser      = "admin"
    JFrogPassword  = "ShipLocal2024!"
    JFrogRepo      = "docker-shipclass-local"
    PgContainer    = "shipclass-postgres"
    PgPort         = 5432
    PgUser         = "pgadmin"
    PgPassword     = "shipclass_local_pw"
    PgDatabases    = @("vessels_db","classification_db","certificates_db",
                       "inspections_db","documents_db")
    Domains = @{
        Api     = "api.shipclass.local"
        App     = "shipclass.local"
        ArgoCD  = "argocd.shipclass.local"
        Grafana = "grafana.shipclass.local"
        JFrog   = "jfrog.shipclass.local"
        Gitea   = "gitea.shipclass.local"
    }
    WorkDir        = (Join-Path $HOME "shipclass-local")
    Services       = @("vessel-service","classification-service","certificate-service",
                       "inspection-service","document-service","notification-service","frontend")
}

function Write-Step  { param($msg) Write-Host "`n>> $msg" -ForegroundColor Cyan }
function Write-OK    { param($msg) Write-Host "  [OK]  $msg" -ForegroundColor Green }
function Write-Fail  { param($msg) Write-Host "  [ERR] $msg" -ForegroundColor Red }
function Write-Info  { param($msg) Write-Host "  [i]   $msg" -ForegroundColor Yellow }
function Write-Title { param($msg) Write-Host "`n$("="*62)`n  $msg`n$("="*62)" -ForegroundColor Magenta }

function Assert-Command { param($Name)
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        Write-Fail "$Name n'est pas installe ou pas dans le PATH"; exit 1
    }
    Write-OK "$Name : $((& $Name --version 2>&1 | Select-Object -First 1) -replace '`n','')"
}

function Apply-Yaml { param($yaml)
    $tmp = [System.IO.Path]::GetTempFileName() + ".yaml"
    $yaml | Out-File $tmp -Encoding UTF8
    kubectl apply -f $tmp
    Remove-Item $tmp -Force
}
