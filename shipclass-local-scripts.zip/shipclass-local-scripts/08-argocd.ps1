#!/usr/bin/env pwsh
# 08-argocd.ps1
# Installe ArgoCD, configure Ingress, connecte le repo Git

param(
    [string]$GitRepo  = "",
    [string]$GitUser  = "admin",
    [string]$GitToken = "",
    [switch]$InstallGitea
)

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 08 - ArgoCD GitOps sur kind"

Write-Step "Installation ArgoCD"
helm repo add argo https://argoproj.github.io/argo-helm --force-update | Out-Null
helm repo update | Out-Null
helm upgrade --install argocd argo/argo-cd `
    --namespace argocd --create-namespace `
    --set configs.params."server\.insecure"=true `
    --set redis.resources.requests.memory=64Mi `
    --set server.resources.requests.memory=128Mi `
    --set repoServer.resources.requests.memory=128Mi `
    --set applicationSet.resources.requests.memory=64Mi `
    --wait --timeout 5m
Write-OK "ArgoCD installe"

Write-Step "Ingress ArgoCD"
Apply-Yaml @"
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: argocd-ingress
  namespace: argocd
  annotations:
    cert-manager.io/cluster-issuer: mkcert-issuer
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/backend-protocol: "HTTP"
spec:
  ingressClassName: nginx
  tls:
  - hosts: [$($SC.Domains.ArgoCD)]
    secretName: argocd-tls
  rules:
  - host: $($SC.Domains.ArgoCD)
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service: { name: argocd-server, port: { number: 80 } }
"@

Write-Step "Recuperation mot de passe admin ArgoCD"
$enc = kubectl get secret argocd-initial-admin-secret -n argocd -o jsonpath="{.data.password}" 2>$null
$argoPw = if ($enc) { [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($enc)) } else { "admin" }
Write-OK "Mot de passe ArgoCD : $argoPw"

if ($InstallGitea) {
    Write-Step "Installation Gitea (serveur Git local)"
    helm repo add gitea-charts https://dl.gitea.com/charts --force-update | Out-Null
    helm repo update | Out-Null
    helm upgrade --install gitea gitea-charts/gitea `
        --namespace gitea --create-namespace `
        --set service.http.type=ClusterIP `
        --set gitea.admin.username=admin `
        --set gitea.admin.password=gitea_local_pw `
        --set gitea.admin.email=admin@shipclass.local `
        --set persistence.size=2Gi `
        --set resources.requests.memory=128Mi `
        --wait --timeout 4m

    Apply-Yaml @"
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: gitea-ingress
  namespace: gitea
  annotations:
    cert-manager.io/cluster-issuer: mkcert-issuer
spec:
  ingressClassName: nginx
  tls:
  - hosts: [$($SC.Domains.Gitea)]
    secretName: gitea-tls
  rules:
  - host: $($SC.Domains.Gitea)
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service: { name: gitea-http, port: { number: 3000 } }
"@
    Write-OK "Gitea : https://$($SC.Domains.Gitea)  (admin/gitea_local_pw)"
    $GitRepo  = "https://$($SC.Domains.Gitea)/admin/k8s-config"
    $GitToken = "gitea_local_pw"
}

Write-Step "Login ArgoCD CLI"
Start-Sleep 8
argocd login $SC.Domains.ArgoCD --username admin --password $argoPw --insecure --grpc-web

if ($GitRepo) {
    Write-Step "Connexion repo Git : $GitRepo"
    argocd repo add $GitRepo --username $GitUser --password $GitToken --insecure-skip-server-verification
    Write-Step "Creation Application ArgoCD shipclass-local"
    argocd app create shipclass-local `
        --repo $GitRepo `
        --path "apps/shipclass/overlays/local" `
        --dest-server https://kubernetes.default.svc `
        --dest-namespace $SC.Namespace `
        --sync-policy automated `
        --auto-prune --self-heal
    argocd app sync shipclass-local
    argocd app list
}

Write-OK "=== ArgoCD pret ! ==="
Write-Info "UI    : https://$($SC.Domains.ArgoCD)"
Write-Info "Login : admin / $argoPw"
