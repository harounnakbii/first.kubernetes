#!/usr/bin/env pwsh
# 04-postgresql.ps1
# Lance PostgreSQL dans Docker, cree les bases, configure le Service K8s

param([switch]$Reset)

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 04 - PostgreSQL local (Docker)"

if ($Reset) {
    docker stop $SC.PgContainer 2>$null; docker rm $SC.PgContainer 2>$null
    docker volume rm shipclass-pgdata 2>$null; Write-OK "Conteneur supprime"
}

Write-Step "Demarrage PostgreSQL"
$st = docker inspect $SC.PgContainer --format "{{.State.Status}}" 2>$null
if ($st -eq "running") {
    Write-Info "PostgreSQL deja en cours"
} elseif ($st -eq "exited") {
    docker start $SC.PgContainer; Write-OK "PostgreSQL redemarre"
} else {
    docker run -d --name $SC.PgContainer --restart unless-stopped `
        -e POSTGRES_PASSWORD=$SC.PgPassword `
        -e POSTGRES_USER=$SC.PgUser `
        -p "$($SC.PgPort):5432" `
        -v shipclass-pgdata:/var/lib/postgresql/data `
        postgres:15-alpine

    Write-Info "Attente demarrage PostgreSQL..."
    $ok = $false
    for ($i = 0; $i -lt 30; $i++) {
        $c = docker exec $SC.PgContainer pg_isready -U $SC.PgUser 2>&1
        if ($c -match "accepting") { $ok = $true; break }
        Start-Sleep 2; Write-Host "  ." -NoNewline
    }
    if (-not $ok) { Write-Fail "PostgreSQL n'a pas demarre"; exit 1 }
    Write-OK "PostgreSQL pret"
}

Write-Step "Creation des bases de donnees"
foreach ($db in $SC.PgDatabases) {
    $ex = docker exec $SC.PgContainer psql -U $SC.PgUser -lqt 2>$null | Select-String "^\s*$db\s*\|"
    if ($ex) { Write-Info "  '$db' existe deja" }
    else {
        docker exec $SC.PgContainer psql -U $SC.PgUser -c "CREATE DATABASE $db;" 2>$null
        Write-OK "  '$db' creee"
    }
}

Write-Step "Service ExternalName K8s -> PostgreSQL"
$dbHost = if ($IsLinux) {
    $gw = docker inspect $SC.PgContainer --format "{{.NetworkSettings.Gateway}}" 2>$null
    if (-not $gw -or $gw -eq "") { $gw = "172.17.0.1" }
    Write-Info "Linux: gateway Docker = $gw"
    $gw
} else { "host.docker.internal" }

Apply-Yaml @"
apiVersion: v1
kind: Service
metadata:
  name: postgres-svc
  namespace: $($SC.Namespace)
spec:
  type: ExternalName
  externalName: $dbHost
  ports:
  - port: 5432
    targetPort: 5432
"@

Write-Step "Secret K8s credentials BDD"
kubectl delete secret pg-credentials -n $SC.Namespace 2>$null
$base = "postgresql://$($SC.PgUser):$($SC.PgPassword)@postgres-svc.$($SC.Namespace).svc.cluster.local:5432"
kubectl create secret generic pg-credentials `
    --from-literal=PG_USER=$SC.PgUser `
    --from-literal=PG_PASSWORD=$SC.PgPassword `
    --from-literal=VESSEL_DB_URL="$base/vessels_db" `
    --from-literal=CLASS_DB_URL="$base/classification_db" `
    --from-literal=CERT_DB_URL="$base/certificates_db" `
    --from-literal=INSPECT_DB_URL="$base/inspections_db" `
    --namespace=$SC.Namespace

Write-OK "=== PostgreSQL pret ! ==="
Write-Info "Connexion directe : localhost:$($SC.PgPort) | $($SC.PgUser) | $($SC.PgPassword)"
