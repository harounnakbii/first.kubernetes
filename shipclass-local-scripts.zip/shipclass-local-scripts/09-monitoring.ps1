#!/usr/bin/env pwsh
# 09-monitoring.ps1
# Installe Prometheus + Grafana sur kind

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 09 - Prometheus + Grafana"

Write-Step "Installation kube-prometheus-stack"
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts --force-update | Out-Null
helm repo update | Out-Null

helm upgrade --install monitoring prometheus-community/kube-prometheus-stack `
    --namespace monitoring --create-namespace `
    --set prometheus.prometheusSpec.retention=1d `
    --set prometheus.prometheusSpec.retentionSize="3GB" `
    --set prometheus.prometheusSpec.resources.requests.memory=256Mi `
    --set prometheus.prometheusSpec.resources.requests.cpu=100m `
    --set grafana.adminPassword=grafana_local_pw `
    --set grafana.resources.requests.memory=128Mi `
    --set grafana.resources.requests.cpu=50m `
    --set alertmanager.enabled=false `
    --set "grafana.ingress.enabled=true" `
    --set "grafana.ingress.ingressClassName=nginx" `
    --set "grafana.ingress.annotations.cert-manager\.io/cluster-issuer=mkcert-issuer" `
    --set "grafana.ingress.hosts[0]=$($SC.Domains.Grafana)" `
    --set "grafana.ingress.tls[0].secretName=grafana-tls" `
    --set "grafana.ingress.tls[0].hosts[0]=$($SC.Domains.Grafana)" `
    --wait --timeout 6m
Write-OK "Prometheus + Grafana installes"

Write-Step "ServiceMonitor pour ShipClass"
Apply-Yaml @"
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: shipclass-monitor
  namespace: monitoring
  labels:
    release: monitoring
spec:
  selector:
    matchLabels:
      app: vessel-service
  namespaceSelector:
    matchNames: [$($SC.Namespace)]
  endpoints:
  - port: http
    path: /metrics
    interval: 30s
"@

Write-OK "=== Monitoring pret ! ==="
Write-Info "Grafana : https://$($SC.Domains.Grafana)  (admin/grafana_local_pw)"
Write-Info "Dashboards recommandes (import via UI) :"
Write-Info "  ID 15760 - Node Exporter Full"
Write-Info "  ID 13770 - Kubernetes Cluster"
Write-Info "  ID 6417  - Kubernetes Pods"
