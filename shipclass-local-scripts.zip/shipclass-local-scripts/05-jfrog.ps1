#!/usr/bin/env pwsh
# 05-jfrog.ps1
# Lance JFrog Artifactory OSS dans Docker, configure les depots et le login Docker

param([switch]$Reset)

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 05 - JFrog Artifactory OSS local"

$JFROG_URL = "http://localhost:$($SC.JFrogPort)"

if ($Reset) {
    docker stop shipclass-jfrog 2>$null; docker rm shipclass-jfrog 2>$null
}

Write-Step "Demarrage JFrog Artifactory OSS"
$st = docker inspect shipclass-jfrog --format "{{.State.Status}}" 2>$null
if ($st -eq "running") {
    Write-Info "JFrog deja en cours"
} else {
    $jfrogData = Join-Path $SC.WorkDir "jfrog/var"
    New-Item -ItemType Directory -Force $jfrogData | Out-Null

    docker run -d --name shipclass-jfrog --restart unless-stopped `
        -p "$($SC.JFrogPort):8082" -p "8081:8081" `
        -v "${jfrogData}:/var/opt/jfrog/artifactory" `
        releases-docker.jfrog.io/jfrog/artifactory-oss:latest

    Write-Info "Attente demarrage JFrog (~90 secondes)..."
    Start-Sleep 90

    $hdrs0 = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("admin:password")) }
    $ok = $false
    for ($i = 0; $i -lt 20; $i++) {
        try {
            $r = Invoke-RestMethod "$JFROG_URL/artifactory/api/system/ping" -Headers $hdrs0 -EA Stop
            if ($r -eq "OK") { $ok = $true; break }
        } catch {}
        Start-Sleep 5; Write-Host "  ." -NoNewline
    }
    if (-not $ok) { Write-Fail "JFrog n'a pas demarre. Voir: docker logs shipclass-jfrog"; exit 1 }
    Write-OK "JFrog demarre"

    # Changer le mot de passe
    $pwBody = @{ userName="admin"; oldPassword="password"; newPassword=$SC.JFrogPassword } | ConvertTo-Json
    try {
        Invoke-RestMethod "$JFROG_URL/artifactory/api/security/users/authorization/changePassword" `
            -Method POST -Headers $hdrs0 -Body $pwBody -ContentType "application/json"
        Write-OK "Mot de passe admin change"
    } catch { Write-Info "Mot de passe deja change" }
}

$hdrs = @{
    Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($SC.JFrogUser):$($SC.JFrogPassword)"))
    "Content-Type" = "application/json"
}

Write-Step "Creation des depots JFrog"
@(
    @{ key=$SC.JFrogRepo; packageType="docker"; rclass="local" },
    @{ key="helm-shipclass-local"; packageType="helm"; rclass="local" }
) | ForEach-Object {
    try {
        Invoke-RestMethod "$JFROG_URL/artifactory/api/repositories/$($_.key)" `
            -Method PUT -Headers $hdrs -Body ($_ | ConvertTo-Json)
        Write-OK "Depot '$($_.key)' cree"
    } catch { Write-Info "Depot '$($_.key)' : $($_.Exception.Message)" }
}

Write-Step "Configuration Docker insecure-registries"
$dp = if ($IsWindows) { "$env:APPDATA\Docker\daemon.json" } `
      elseif ($IsMacOS) { "$HOME/.docker/daemon.json" } `
      else { "/etc/docker/daemon.json" }

$dc = if (Test-Path $dp) { Get-Content $dp -Raw | ConvertFrom-Json } else { [PSCustomObject]@{} }
if (-not $dc.'insecure-registries') {
    $dc | Add-Member -Name "insecure-registries" -Value @("localhost:$($SC.JFrogPort)") -MemberType NoteProperty
    $dc | ConvertTo-Json | Out-File $dp -Encoding UTF8
    Write-Info "daemon.json mis a jour. Redemarrer Docker Desktop."
}

docker login "localhost:$($SC.JFrogPort)" -u $SC.JFrogUser -p $SC.JFrogPassword
Write-OK "Login Docker -> JFrog OK"

kubectl delete secret jfrog-local-secret -n $SC.Namespace 2>$null
kubectl create secret docker-registry jfrog-local-secret `
    --docker-server="localhost:$($SC.JFrogPort)" `
    --docker-username=$SC.JFrogUser `
    --docker-password=$SC.JFrogPassword `
    --namespace=$SC.Namespace
Write-OK "Secret imagePullSecret cree"

Write-OK "=== JFrog Artifactory pret ! === http://localhost:$($SC.JFrogPort)"
