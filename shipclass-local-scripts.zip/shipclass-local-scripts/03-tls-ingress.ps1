#!/usr/bin/env pwsh
# 03-tls-ingress.ps1
# mkcert -> CA locale -> cert-manager -> ClusterIssuer -> Ingress NGINX -> /etc/hosts

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 03 - TLS local (mkcert + cert-manager) + Ingress NGINX"

# ── mkcert ────────────────────────────────────────────────────
Write-Step "Initialisation mkcert"
mkcert -install
if ($LASTEXITCODE -ne 0) { Write-Fail "mkcert -install echoue"; exit 1 }
$CAROOT = (mkcert -CAROOT).Trim()
Write-OK "CA mkcert dans : $CAROOT"

# ── cert-manager ──────────────────────────────────────────────
Write-Step "Installation cert-manager via Helm"
helm repo add jetstack https://charts.jetstack.io --force-update | Out-Null
helm repo update | Out-Null
helm upgrade --install cert-manager jetstack/cert-manager `
    --namespace cert-manager --create-namespace `
    --version v1.14.0 --set installCRDs=true `
    --set resources.requests.cpu=50m `
    --set resources.requests.memory=64Mi `
    --wait --timeout 3m
Write-OK "cert-manager installe"

# ── Secret CA dans K8s ────────────────────────────────────────
Write-Step "Import CA mkcert dans Kubernetes"
kubectl delete secret mkcert-ca-secret -n cert-manager 2>$null
kubectl create secret tls mkcert-ca-secret `
    --cert="$CAROOT/rootCA.pem" `
    --key="$CAROOT/rootCA-key.pem" `
    --namespace cert-manager
Write-OK "Secret CA cree"

# ── ClusterIssuer ─────────────────────────────────────────────
Apply-Yaml @"
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: mkcert-issuer
spec:
  ca:
    secretName: mkcert-ca-secret
"@
Start-Sleep 5
Write-OK "ClusterIssuer mkcert-issuer cree"

# ── Ingress NGINX ─────────────────────────────────────────────
Write-Step "Installation Ingress NGINX (version kind)"
kubectl apply -f "https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml"
kubectl wait --namespace ingress-nginx `
    --for=condition=ready pod `
    --selector=app.kubernetes.io/component=controller `
    --timeout=120s
Write-OK "Ingress NGINX pret"

# ── /etc/hosts ────────────────────────────────────────────────
Write-Step "Configuration /etc/hosts"
$hostsPath = if ($IsWindows) { "C:\Windows\System32\drivers\etc\hosts" } else { "/etc/hosts" }
$current = Get-Content $hostsPath -ErrorAction SilentlyContinue

foreach ($domain in $SC.Domains.Values) {
    $entry = "127.0.0.1  $domain"
    if ($current -notcontains $entry) {
        if ($IsWindows) { Add-Content -Path $hostsPath -Value $entry }
        else { $entry | sudo tee -a $hostsPath | Out-Null }
        Write-OK "Ajoute : $entry"
    } else { Write-Info "Deja present : $entry" }
}

# ── Certificat global ─────────────────────────────────────────
Write-Step "Emission du certificat TLS"
kubectl create namespace $SC.Namespace 2>$null
$dnsNames = ($SC.Domains.Values | ForEach-Object { "  - $_" }) -join "`n"

Apply-Yaml @"
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: shipclass-tls
  namespace: $($SC.Namespace)
spec:
  secretName: shipclass-tls-secret
  duration: 8760h
  renewBefore: 720h
  dnsNames:
$dnsNames
  issuerRef:
    name: mkcert-issuer
    kind: ClusterIssuer
"@

# Attendre emission
for ($i = 0; $i -lt 30; $i++) {
    $r = kubectl get certificate shipclass-tls -n $SC.Namespace -o jsonpath="{.status.conditions[0].status}" 2>$null
    if ($r -eq "True") { Write-OK "Certificat emis (READY=True)"; break }
    Start-Sleep 2; Write-Host "  ." -NoNewline
}

Write-OK "=== TLS + Ingress NGINX prets ! ==="
