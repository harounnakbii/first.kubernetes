#!/usr/bin/env pwsh
# 00-bootstrap.ps1
# Lance l'installation complete de l'environnement ShipClass local dans l'ordre
# Usage : ./00-bootstrap.ps1
#         ./00-bootstrap.ps1 -SkipTools       (si deja installes)
#         ./00-bootstrap.ps1 -GitRepo <url> -GitToken <token>

param(
    [switch]$SkipTools,
    [switch]$SkipJFrog,
    [string]$GitRepo  = "",
    [string]$GitToken = ""
)

$ErrorActionPreference = "Continue"

Write-Host @"

  +============================================================+
  |   ShipClass Local - Bootstrap Complet                     |
  |   Kubernetes (kind) + ArgoCD + JFrog + cert-manager       |
  |   PostgreSQL + Prometheus + Grafana + Ingress NGINX        |
  +============================================================+

"@ -ForegroundColor Cyan

$start = Get-Date

$steps = @(
    @{ Script="01-install-tools.ps1";   Skip=$SkipTools; Label="Installation des outils" },
    @{ Script="02-create-cluster.ps1";  Skip=$false;     Label="Cluster kind + Registry" },
    @{ Script="03-tls-ingress.ps1";     Skip=$false;     Label="TLS mkcert + Ingress NGINX" },
    @{ Script="04-postgresql.ps1";      Skip=$false;     Label="PostgreSQL local" },
    @{ Script="05-jfrog.ps1";           Skip=$SkipJFrog; Label="JFrog Artifactory OSS" },
    @{ Script="06-build-images.ps1";    Skip=$false;     Label="Build des images Docker" },
    @{ Script="07-deploy-services.ps1"; Skip=$false;     Label="Deploiement microservices" },
    @{ Script="08-argocd.ps1";          Skip=$false;     Label="ArgoCD GitOps" },
    @{ Script="09-monitoring.ps1";      Skip=$false;     Label="Prometheus + Grafana" },
    @{ Script="11-verify.ps1";          Skip=$false;     Label="Verification finale" }
)

$i = 0; $ok = 0; $ko = 0
foreach ($step in $steps) {
    $i++
    if ($step.Skip) {
        Write-Host "  [SKIP] [$i/$($steps.Count)] $($step.Label)" -ForegroundColor DarkGray
        continue
    }
    Write-Host "`n  [>>>] [$i/$($steps.Count)] $($step.Label)..." -ForegroundColor Yellow
    $sp = Join-Path $PSScriptRoot $step.Script
    if (-not (Test-Path $sp)) { Write-Host "  [SKIP] Script $($step.Script) introuvable" -ForegroundColor DarkGray; continue }
    try {
        if ($step.Script -eq "08-argocd.ps1" -and $GitRepo) {
            & $sp -GitRepo $GitRepo -GitToken $GitToken
        } else { & $sp }
        Write-Host "  [OK]  $($step.Label)" -ForegroundColor Green; $ok++
    } catch {
        Write-Host "  [ERR] $($step.Label) : $($_.Exception.Message)" -ForegroundColor Red; $ko++
        $ans = Read-Host "  Continuer quand meme ? (o/n)"
        if ($ans -ne "o") { break }
    }
}

$dur = [math]::Round(((Get-Date) - $start).TotalMinutes, 1)
Write-Host @"

  +============================================================+
  |  Termine en $dur minutes  ($ok OK, $ko erreur(s))              |
  +------------------------------------------------------------+
  |  API       https://api.shipclass.local                     |
  |  App       https://shipclass.local                         |
  |  ArgoCD    https://argocd.shipclass.local                  |
  |  Grafana   https://grafana.shipclass.local                 |
  |  JFrog     http://localhost:8082  (admin/ShipLocal2024!)   |
  |  PostgreSQL localhost:5432  (pgadmin/shipclass_local_pw)   |
  +------------------------------------------------------------+
  |  Commandes quotidiennes :                                  |
  |    ./10-daily.ps1 -Action start                            |
  |    ./10-daily.ps1 -Action status                           |
  |    ./10-daily.ps1 -Action rebuild -Service vessel-service  |
  |    ./10-daily.ps1 -Action db                               |
  |    ./10-daily.ps1 -Action logs -Service vessel-service     |
  +============================================================+
"@ -ForegroundColor Cyan
