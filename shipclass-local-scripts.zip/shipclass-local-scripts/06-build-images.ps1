#!/usr/bin/env pwsh
# 06-build-images.ps1
# Build et push de toutes les images Docker des microservices ShipClass

param(
    [string]$Service  = "all",
    [string]$Tag      = "latest",
    [ValidateSet("kind","jfrog")]
    [string]$Registry = "kind",
    [switch]$ScanCVE
)

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 06 - Build & Push des images ($Registry)"

$reg = if ($Registry -eq "jfrog") { "localhost:$($SC.JFrogPort)/$($SC.JFrogRepo)" } else { $SC.Registry }
Write-Info "Registry : $reg  |  Tag : $Tag"

$services = if ($Service -eq "all") { $SC.Services } else { @($Service) }
$root = Split-Path $PSScriptRoot -Parent
$results = @()

foreach ($svc in $services) {
    Write-Step "Build : $svc"
    $svcPath = if ($svc -eq "frontend") { Join-Path $root "frontend" } else { Join-Path $root "services" $svc }

    if (-not (Test-Path (Join-Path $svcPath "Dockerfile"))) {
        Write-Info "Dockerfile absent - creation d'un service de demo"
        New-Item -ItemType Directory -Force $svcPath | Out-Null
        $port = switch ($svc) {
            "vessel-service"         { 3001 }
            "classification-service" { 3002 }
            "certificate-service"    { 3003 }
            "inspection-service"     { 3004 }
            "document-service"       { 3005 }
            "notification-service"   { 3006 }
            default                  { 3000 }
        }
        @"
FROM node:20-alpine
RUN addgroup -S app && adduser -S app -G app
WORKDIR /app
RUN printf '{"name":"$svc","version":"1.0.0","main":"index.js"}' > package.json
RUN printf 'const http=require("http"),os=require("os");const s=http.createServer((q,r)=>{const h={"Content-Type":"application/json"};if(q.url==="/health"||q.url==="/ready"){r.writeHead(200,h);r.end(JSON.stringify({status:"ok",service:"$svc",version:"$Tag",host:os.hostname()}))}else{r.writeHead(200,h);r.end(JSON.stringify({service:"$svc",message:"ShipClass local demo"}))}});s.listen($port,()=>console.log("$svc listening on :$port"));' > index.js
USER app
EXPOSE $port
HEALTHCHECK --interval=30s --timeout=5s CMD wget -qO- http://localhost:$port/health||exit 1
CMD ["node","index.js"]
"@ | Out-File "$svcPath/Dockerfile" -Encoding UTF8
    }

    $imgTag = "$reg/$svc`:$Tag"
    $imgLatest = "$reg/$svc`:latest"

    docker build -t $imgTag -t $imgLatest $svcPath
    if ($LASTEXITCODE -ne 0) {
        $results += [PSCustomObject]@{ Service=$svc; Status="BUILD_FAIL" }; continue
    }

    if ($ScanCVE -and (Get-Command trivy -EA SilentlyContinue)) {
        Write-Info "Scan Trivy CVE..."
        trivy image --severity HIGH,CRITICAL --exit-code 0 $imgTag
    }

    docker push $imgTag
    if ($Tag -ne "latest") { docker push $imgLatest }

    $results += [PSCustomObject]@{ Service=$svc; Status="OK"; Image=$imgTag }
    Write-OK "$svc -> $imgTag"
}

Write-Title "Resume du build"
$results | Format-Table -AutoSize
$ko = $results | Where-Object { $_.Status -ne "OK" }
if ($ko) { Write-Fail "$($ko.Count) echec(s)" } else { Write-OK "Tous les services buildes et pushes !" }
