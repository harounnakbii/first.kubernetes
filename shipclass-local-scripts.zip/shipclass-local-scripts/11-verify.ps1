#!/usr/bin/env pwsh
# 11-verify.ps1
# Tests de bout-en-bout pour valider que tout fonctionne

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 11 - Verification complete de l'environnement"

$errors = 0
function TC { param($Name, $Block)
    try {
        $r = & $Block
        if ($r) { Write-OK $Name } else { Write-Fail $Name; $script:errors++ }
    } catch { Write-Fail "$Name : $($_.Exception.Message)"; $script:errors++ }
}

Write-Step "Docker"
TC "Docker operationnel"      { docker info *>$null; $LASTEXITCODE -eq 0 }
TC "PostgreSQL running"        { (docker inspect $SC.PgContainer --format "{{.State.Status}}" 2>$null) -eq "running" }
TC "Kind Registry running"     { (docker inspect $SC.RegistryName --format "{{.State.Status}}" 2>$null) -eq "running" }

Write-Step "Kubernetes"
TC "Cluster accessible"       { kubectl cluster-info 2>$null; $LASTEXITCODE -eq 0 }
TC "Noeuds Ready (min 2)"      {
    $n = kubectl get nodes --no-headers 2>$null
    ($n -split "`n" | Where-Object { $_ -match " Ready " }).Count -ge 2
}

Write-Step "Pods ShipClass"
$pods = kubectl get pods -n $SC.Namespace --no-headers 2>$null
if ($pods) {
    ($pods -split "`n") | Where-Object { $_ -ne "" } | ForEach-Object {
        $c = $_ -split '\s+'
        TC "Pod $($c[0])" { $c[2] -eq "Running" }
    }
} else { Write-Info "Aucun pod dans $($SC.Namespace)" }

Write-Step "Certificats TLS"
$certs = kubectl get certificates -A --no-headers 2>$null
if ($certs) {
    ($certs -split "`n") | Where-Object { $_ -ne "" } | ForEach-Object {
        $c = $_ -split '\s+'
        TC "Certificat $($c[1]) READY" { $c[2] -eq "True" }
    }
}

Write-Step "API HTTPS"
TC "https://$($SC.Domains.Api)/vessels/health" {
    try { (Invoke-WebRequest "https://$($SC.Domains.Api)/vessels/health" -UseBasicParsing -TimeoutSec 5 -EA Stop).StatusCode -eq 200 }
    catch { $false }
}
TC "ArgoCD UI accessible" {
    try { (Invoke-WebRequest "https://$($SC.Domains.ArgoCD)" -UseBasicParsing -TimeoutSec 5 -EA Stop).StatusCode -in @(200,307) }
    catch { $false }
}
TC "Grafana UI accessible" {
    try { (Invoke-WebRequest "https://$($SC.Domains.Grafana)" -UseBasicParsing -TimeoutSec 5 -EA Stop).StatusCode -eq 200 }
    catch { $false }
}

Write-Step "PostgreSQL"
TC "vessels_db accessible" {
    $r = docker exec $SC.PgContainer psql -U $SC.PgUser -d vessels_db -c "\l" -q 2>&1
    $r -match "vessels_db"
}

Write-Step "Test fonctionnel : creation d'un navire"
try {
    $body = @{ imo_number="IMO9999$(Get-Random -Max 999)"; name="MV Test Local"; flag="FR"; type="Bulk Carrier"; grt=45000 } | ConvertTo-Json
    $r = Invoke-RestMethod "https://$($SC.Domains.Api)/vessels" -Method POST -ContentType "application/json" -Body $body -EA Stop
    Write-OK "Navire cree : $($r.name) (ID: $($r.id))"
} catch { Write-Info "Test creation navire : $($_.Exception.Message)" }

Write-Title "Resume"
if ($errors -eq 0) { Write-OK "TOUS LES TESTS REUSSIS - Environnement 100% operationnel !" }
else {
    Write-Fail "$errors test(s) en echec"
    Write-Info "Debug : ./10-daily.ps1 -Action status"
    Write-Info "Logs  : ./10-daily.ps1 -Action logs -Service <nom>"
}
