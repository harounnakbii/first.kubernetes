#!/usr/bin/env pwsh
# 02-create-cluster.ps1
# Cree le cluster kind local (1 control-plane + 2 workers) + registry Docker local

param([switch]$Reset)

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 02 - Creation du cluster kind"

docker info *>$null
if ($LASTEXITCODE -ne 0) { Write-Fail "Docker n'est pas lance. Demarrer Docker Desktop."; exit 1 }
Write-OK "Docker operationnel"

if ($Reset) {
    Write-Step "Suppression cluster + registry existants"
    kind delete cluster --name $SC.ClusterName 2>$null
    docker rm -f $SC.RegistryName 2>$null
    Write-OK "Suppression effectuee"
}

New-Item -ItemType Directory -Force $SC.WorkDir | Out-Null

# ── Config kind ────────────────────────────────────────────────
Write-Step "Generation du fichier kind-config.yaml"
@"
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
name: $($SC.ClusterName)
nodes:
- role: control-plane
  kubeadmConfigPatches:
  - |
    kind: InitConfiguration
    nodeRegistration:
      kubeletExtraArgs:
        node-labels: "ingress-ready=true"
  extraPortMappings:
  - containerPort: 80
    hostPort: 80
    protocol: TCP
  - containerPort: 443
    hostPort: 443
    protocol: TCP
- role: worker
- role: worker
containerdConfigPatches:
- |-
  [plugins."io.containerd.grpc.v1.cri".registry.mirrors."localhost:5001"]
    endpoint = ["http://$($SC.RegistryName):5000"]
"@ | Out-File "$($SC.WorkDir)/kind-config.yaml" -Encoding UTF8
Write-OK "kind-config.yaml cree"

# ── Registry local ─────────────────────────────────────────────
Write-Step "Registry Docker local (localhost:5001)"
$st = docker inspect $SC.RegistryName --format "{{.State.Status}}" 2>$null
if ($st -ne "running") {
    docker run -d --restart=always -p "127.0.0.1:5001:5000" `
        --network bridge --name $SC.RegistryName registry:2
    Write-OK "Registry lance"
} else { Write-Info "Registry deja en cours" }

# ── Cluster kind ───────────────────────────────────────────────
Write-Step "Creation du cluster kind"
$existing = kind get clusters 2>$null | Where-Object { $_ -eq $SC.ClusterName }
if ($existing) {
    Write-Info "Cluster deja existant. Utiliser -Reset pour recreer."
} else {
    kind create cluster --config "$($SC.WorkDir)/kind-config.yaml"
    if ($LASTEXITCODE -ne 0) { Write-Fail "Echec creation cluster"; exit 1 }
    Write-OK "Cluster cree"
}

# Connecter registry au reseau kind
$nets = docker inspect $SC.RegistryName --format "{{json .NetworkSettings.Networks}}" 2>$null
if ($nets -notmatch '"kind"') {
    docker network connect kind $SC.RegistryName 2>$null
    Write-OK "Registry connecte au reseau kind"
}

# ConfigMap registry
Apply-Yaml @"
apiVersion: v1
kind: ConfigMap
metadata:
  name: local-registry-hosting
  namespace: kube-public
data:
  localRegistryHosting.v1: |
    host: "localhost:5001"
    help: "https://kind.sigs.k8s.io/docs/user/local-registry/"
"@

kubectl config use-context $SC.Context
kubectl get nodes

# Test registry
docker pull alpine:latest --quiet 2>$null
docker tag alpine:latest localhost:5001/smoke:test
docker push localhost:5001/smoke:test
$cat = Invoke-RestMethod "http://localhost:5001/v2/_catalog"
if ($cat.repositories -contains "smoke") { Write-OK "Registry local fonctionnel" }

Write-OK "=== Cluster kind et registry prets ! ==="
