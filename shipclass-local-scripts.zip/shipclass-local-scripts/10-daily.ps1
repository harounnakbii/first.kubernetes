#!/usr/bin/env pwsh
# 10-daily.ps1
# Commandes quotidiennes : start, stop, status, rebuild, db, logs, reset-all

param(
    [ValidateSet("start","stop","status","rebuild","db","logs","reset-all","port-forward")]
    [string]$Action = "status",
    [string]$Service = "all",
    [string]$Tag = "latest"
)

. "$PSScriptRoot/config.ps1"
Write-Title "DAILY - Action : $Action"

switch ($Action) {

    "start" {
        Write-Step "Demarrage de l'environnement"
        docker info *>$null
        if ($LASTEXITCODE -ne 0) { Write-Fail "Docker non lance !"; exit 1 }

        @($SC.PgContainer, "shipclass-jfrog") | ForEach-Object {
            $st = docker inspect $_ --format "{{.State.Status}}" 2>$null
            if ($st -eq "exited") { docker start $_; Write-OK "$_ demarre" }
            elseif ($st -eq "running") { Write-Info "$_ deja en cours" }
            else { Write-Info "$_ non cree" }
        }

        kubectl config use-context $SC.Context 2>$null
        $nodes = kubectl get nodes --no-headers 2>$null
        if ($nodes -match "Ready") { Write-OK "Cluster kind operationnel" }

        Write-OK "URLs disponibles :"
        Write-Info "  API     : https://$($SC.Domains.Api)/vessels/health"
        Write-Info "  ArgoCD  : https://$($SC.Domains.ArgoCD)"
        Write-Info "  Grafana : https://$($SC.Domains.Grafana)"
        Write-Info "  JFrog   : http://localhost:$($SC.JFrogPort)"
    }

    "stop" {
        docker stop $SC.PgContainer 2>$null; Write-OK "PostgreSQL arrete"
        docker stop shipclass-jfrog 2>$null; Write-OK "JFrog arrete"
        Write-Info "Cluster kind conserve en memoire (redemarrage automatique avec Docker)"
    }

    "status" {
        Write-Info "--- Docker ---"
        @($SC.PgContainer, "shipclass-jfrog", $SC.RegistryName) | ForEach-Object {
            $st = docker inspect $_ --format "{{.State.Status}}" 2>$null
            $ico = if ($st -eq "running") { "[OK]" } else { "[KO]" }
            Write-Host "  $ico  $_ : $(if ($st) { $st } else { 'non cree' })"
        }
        Write-Info "`n--- Pods ShipClass ---"
        kubectl get pods -n $SC.Namespace --no-headers 2>$null

        Write-Info "`n--- Certificats TLS ---"
        kubectl get certificates -A --no-headers 2>$null

        Write-Info "`n--- ArgoCD Apps ---"
        argocd app list --grpc-web 2>$null
    }

    "rebuild" {
        & "$PSScriptRoot/06-build-images.ps1" -Service $Service -Tag $Tag
        if ($LASTEXITCODE -eq 0) {
            if ($Service -eq "all") {
                $SC.Services | ForEach-Object {
                    kubectl rollout restart deployment/$_ -n $SC.Namespace 2>$null
                }
            } else {
                kubectl rollout restart deployment/$Service -n $SC.Namespace
                kubectl rollout status  deployment/$Service -n $SC.Namespace --timeout=90s
            }
        }
    }

    "db" {
        Write-Info "Session psql sur vessels_db (Ctrl+D ou \q pour quitter)"
        docker exec -it $SC.PgContainer psql -U $SC.PgUser -d vessels_db
    }

    "logs" {
        if ($Service -eq "all") { Write-Info "Specifier -Service <nom>"; return }
        kubectl logs -f deployment/$Service -n $SC.Namespace --tail=100
    }

    "port-forward" {
        Write-Info "Port-forwards disponibles :"
        Write-Info "  PostgreSQL  : kubectl port-forward svc/postgres-svc 5432:5432 -n $($SC.Namespace)"
        Write-Info "  Prometheus  : kubectl port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090 -n monitoring"
        Write-Info "  ArgoCD API  : kubectl port-forward svc/argocd-server 8443:443 -n argocd"
        Write-Info "En lancer un : kubectl port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090 -n monitoring"
        kubectl port-forward svc/monitoring-kube-prometheus-prometheus 9090:9090 -n monitoring
    }

    "reset-all" {
        Write-Info "ATTENTION : toutes les donnees seront supprimees !"
        $confirm = Read-Host "Confirmer ? (oui/non)"
        if ($confirm -ne "oui") { Write-Info "Annule"; return }
        kind delete cluster --name $SC.ClusterName 2>$null
        docker stop $SC.PgContainer shipclass-jfrog $SC.RegistryName 2>$null
        docker rm   $SC.PgContainer shipclass-jfrog $SC.RegistryName 2>$null
        docker volume rm shipclass-pgdata 2>$null
        Write-OK "Reset complet. Relancer 02-create-cluster.ps1 pour recommencer."
    }
}
