#!/usr/bin/env pwsh
# 07-deploy-services.ps1
# Deploie les microservices ShipClass sur le cluster kind

param(
    [string]$Service  = "all",
    [ValidateSet("kind","jfrog")]
    [string]$Registry = "kind",
    [string]$Tag      = "latest"
)

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 07 - Deploiement des microservices sur kind"

$reg = if ($Registry -eq "jfrog") { "localhost:$($SC.JFrogPort)/$($SC.JFrogRepo)" } else { $SC.Registry }
$ns  = $SC.Namespace

kubectl create namespace $ns 2>$null

Write-Step "ConfigMap global"
Apply-Yaml @"
apiVersion: v1
kind: ConfigMap
metadata:
  name: shipclass-config
  namespace: $ns
data:
  NODE_ENV: development
  LOG_LEVEL: debug
  POSTGRES_HOST: postgres-svc.$ns.svc.cluster.local
  POSTGRES_PORT: "5432"
  POSTGRES_USER: $($SC.PgUser)
  JFROG_URL: http://host.docker.internal:$($SC.JFrogPort)/artifactory
"@

Write-Step "Secret applicatif"
kubectl delete secret shipclass-app-secrets -n $ns 2>$null
kubectl create secret generic shipclass-app-secrets `
    --from-literal=POSTGRES_PASSWORD=$SC.PgPassword `
    --from-literal=JWT_SECRET="$(New-Guid)-local-dev" `
    --from-literal=AIS_API_KEY="mock-ais-key-local" `
    --namespace=$ns

$svcDefs = @(
    @{ Name="vessel-service";         Port=3001; SvcName="vessel-svc";         Path="/vessels" },
    @{ Name="classification-service"; Port=3002; SvcName="classification-svc"; Path="/classifications" },
    @{ Name="certificate-service";    Port=3003; SvcName="certificate-svc";    Path="/certificates" },
    @{ Name="inspection-service";     Port=3004; SvcName="inspection-svc";     Path="/inspections" },
    @{ Name="document-service";       Port=3005; SvcName="document-svc";       Path="/documents" },
    @{ Name="notification-service";   Port=3006; SvcName="notification-svc";   Path="/notifications" },
    @{ Name="frontend";               Port=3000; SvcName="frontend-svc";       Path="/" }
)

$selected = if ($Service -eq "all") { $svcDefs } else { $svcDefs | Where-Object { $_.Name -eq $Service } }

foreach ($svc in $selected) {
    Write-Step "Deploiement : $($svc.Name)"
    $img = "$reg/$($svc.Name):$Tag"

    Apply-Yaml @"
apiVersion: apps/v1
kind: Deployment
metadata:
  name: $($svc.Name)
  namespace: $ns
  labels: { app: $($svc.Name), version: "$Tag" }
spec:
  replicas: 1
  selector:
    matchLabels:
      app: $($svc.Name)
  template:
    metadata:
      labels: { app: $($svc.Name), version: "$Tag" }
    spec:
      imagePullSecrets:
      - name: jfrog-local-secret
      containers:
      - name: $($svc.Name)
        image: $img
        imagePullPolicy: Always
        ports:
        - containerPort: $($svc.Port)
        envFrom:
        - configMapRef: { name: shipclass-config }
        - secretRef:    { name: shipclass-app-secrets }
        - secretRef:    { name: pg-credentials }
        resources:
          requests: { cpu: 50m, memory: 128Mi }
          limits:   { cpu: 300m, memory: 256Mi }
        livenessProbe:
          httpGet: { path: /health, port: $($svc.Port) }
          initialDelaySeconds: 20
          periodSeconds: 30
        readinessProbe:
          httpGet: { path: /health, port: $($svc.Port) }
          initialDelaySeconds: 10
          periodSeconds: 10
        securityContext:
          runAsNonRoot: true
          runAsUser: 1000
          allowPrivilegeEscalation: false
---
apiVersion: v1
kind: Service
metadata:
  name: $($svc.SvcName)
  namespace: $ns
spec:
  selector: { app: $($svc.Name) }
  ports:
  - port: 80
    targetPort: $($svc.Port)
  type: ClusterIP
"@
    Write-OK "$($svc.Name) -> $img"
}

Write-Step "Ingress global"
$paths = ($selected | Where-Object { $_.Path -ne "/" } | ForEach-Object {
    "      - path: $($_.Path)`n        pathType: Prefix`n        backend:`n          service:`n            name: $($_.SvcName)`n            port:`n              number: 80"
}) -join "`n"

Apply-Yaml @"
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: shipclass-api-ingress
  namespace: $ns
  annotations:
    cert-manager.io/cluster-issuer: mkcert-issuer
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/proxy-body-size: "20m"
    nginx.ingress.kubernetes.io/enable-cors: "true"
    nginx.ingress.kubernetes.io/cors-allow-origin: "*"
spec:
  ingressClassName: nginx
  tls:
  - hosts: [$($SC.Domains.Api)]
    secretName: shipclass-tls-secret
  rules:
  - host: $($SC.Domains.Api)
    http:
      paths:
$paths
"@

Write-Step "Verification du deploiement"
foreach ($svc in $selected) {
    kubectl rollout status deployment/$($svc.Name) -n $ns --timeout=90s
}

Write-OK "=== Microservices deployes ! ==="
kubectl get pods -n $ns
Write-Info "API  : https://$($SC.Domains.Api)/vessels/health"
