#!/usr/bin/env pwsh
# 01-install-tools.ps1
# Installe tous les outils requis selon l'OS detecte
# Windows : executer en tant qu'Administrateur

param([switch]$Verify)

. "$PSScriptRoot/config.ps1"
Write-Title "ETAPE 01 - Installation des outils"

$os = if ($IsWindows) { "windows" } elseif ($IsMacOS) { "macos" } else { "linux" }
Write-Info "OS detecte : $os"

if ($Verify) {
    Write-Step "Verification des outils"
    @("docker","kubectl","helm","kind","argocd","mkcert","git","jq") | ForEach-Object {
        if (Get-Command $_ -ErrorAction SilentlyContinue) {
            Write-OK "$_ disponible"
        } else { Write-Fail "$_ : NON INSTALLE" }
    }
    return
}

# =========================================================
# WINDOWS
# =========================================================
if ($IsWindows) {
    Write-Step "Installation via winget"
    @(
        "Docker.DockerDesktop",
        "Kubernetes.kubectl",
        "Helm.Helm",
        "Git.Git",
        "jqlang.jq",
        "Microsoft.PowerShell"
    ) | ForEach-Object {
        Write-Info "winget install $_"
        winget install --id $_ --silent --accept-package-agreements --accept-source-agreements 2>&1 | Out-Null
        Write-OK "  $_ installe"
    }

    Write-Step "Installation Scoop (kind + mkcert)"
    if (-not (Get-Command scoop -ErrorAction SilentlyContinue)) {
        Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
        Invoke-RestMethod https://get.scoop.sh | Invoke-Expression
    }
    scoop install kind mkcert

    Write-Step "Installation ArgoCD CLI"
    $v = (Invoke-RestMethod https://api.github.com/repos/argoproj/argo-cd/releases/latest).tag_name
    Invoke-WebRequest "https://github.com/argoproj/argo-cd/releases/download/$v/argocd-windows-amd64.exe" `
        -OutFile "$env:LOCALAPPDATA\Microsoft\WindowsApps\argocd.exe" -UseBasicParsing
    Write-OK "ArgoCD CLI installe"

    Write-Step "Activation WSL2 (requis pour Docker Desktop)"
    wsl --install --no-distribution 2>&1 | Out-Null
    Write-Info "Un redemarrage peut etre necessaire apres WSL2"
}

# =========================================================
# MACOS
# =========================================================
elseif ($IsMacOS) {
    Write-Step "Installation via Homebrew"
    if (-not (Get-Command brew -ErrorAction SilentlyContinue)) {
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    }
    @("kubectl","helm","kind","git","jq","mkcert","argocd","derailed/k9s/k9s") | ForEach-Object {
        Write-Info "brew install $_"
        brew install $_ 2>&1 | Select-Object -Last 1
    }
    Write-Step "Docker Desktop macOS"
    brew install --cask docker
    Write-Info "Lancer Docker Desktop depuis les Applications"
}

# =========================================================
# LINUX
# =========================================================
else {
    Write-Step "Installation sur Linux (Ubuntu/Debian)"

    bash -c "curl -fsSL https://get.docker.com | sh"
    sudo usermod -aG docker $env:USER

    $k8sVer = (Invoke-RestMethod https://dl.k8s.io/release/stable.txt).Trim()
    Invoke-WebRequest "https://dl.k8s.io/release/$k8sVer/bin/linux/amd64/kubectl" -OutFile /tmp/kubectl
    sudo chmod +x /tmp/kubectl; sudo mv /tmp/kubectl /usr/local/bin/

    bash -c "curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash"

    Invoke-WebRequest "https://kind.sigs.k8s.io/dl/v0.23.0/kind-linux-amd64" -OutFile /tmp/kind
    sudo chmod +x /tmp/kind; sudo mv /tmp/kind /usr/local/bin/

    sudo apt-get install -y libnss3-tools -qq
    Invoke-WebRequest "https://github.com/FiloSottile/mkcert/releases/download/v1.4.4/mkcert-v1.4.4-linux-amd64" -OutFile /tmp/mkcert
    sudo chmod +x /tmp/mkcert; sudo mv /tmp/mkcert /usr/local/bin/

    Invoke-WebRequest "https://github.com/argoproj/argo-cd/releases/latest/download/argocd-linux-amd64" -OutFile /tmp/argocd
    sudo chmod +x /tmp/argocd; sudo mv /tmp/argocd /usr/local/bin/

    sudo apt-get install -y jq -qq
}

Write-Step "Verification finale"
& "$PSScriptRoot/01-install-tools.ps1" -Verify
